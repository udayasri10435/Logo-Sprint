/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { TopBar } from './components/TopBar';
import { SprintHUD } from './components/SprintHUD';
import { CanvasEditor } from './components/CanvasEditor';
import { RivalStations } from './components/RivalStations';
import { MysteryBasketView } from './components/MysteryBasketView';
import { AudienceVotingView } from './components/AudienceVotingView';
import { ChoppingBlock } from './components/ChoppingBlock';
import { MockupPreview } from './components/MockupPreview';
import { TwistModal } from './components/TwistModal';
import { NewBriefModal } from './components/NewBriefModal';
import {
  CanvasElement,
  Designer,
  GamePhase,
  MysteryBrief
} from './types';
import { MYSTERY_BRIEFS } from './data/briefs';
import { getRivalDesigners } from './data/rivals';
import { sound } from './utils/audio';

export default function App() {
  // Active Brief
  const [currentBrief, setCurrentBrief] = useState<MysteryBrief>(MYSTERY_BRIEFS[0]);

  // Phase & Navigation state
  const [currentPhase, setCurrentPhase] = useState<GamePhase>('SPRINT_ACTIVE');
  const [activeTab, setActiveTab] = useState<'arena' | 'rivals' | 'brief' | 'voting' | 'judges' | 'mockups'>('arena');

  // Audio mute state
  const [isMuted, setIsMuted] = useState<boolean>(false);

  // Sprint Timer State: 60 minutes = 3600 seconds
  const TOTAL_SECONDS = 3600;
  const [secondsLeft, setSecondsLeft] = useState<number>(TOTAL_SECONDS);
  const [isTimerRunning, setIsTimerRunning] = useState<boolean>(true);
  const [speedMultiplier, setSpeedMultiplier] = useState<number>(1);
  const [twistTriggered, setTwistTriggered] = useState<boolean>(false);
  const [showTwistModal, setShowTwistModal] = useState<boolean>(false);
  const [showNewBriefModal, setShowNewBriefModal] = useState<boolean>(false);

  // Station 1 (User) Canvas elements & rationale
  const [userElements, setUserElements] = useState<CanvasElement[]>([
    {
      id: 'init-shape-1',
      type: 'shape',
      shapeType: 'circle',
      x: 160,
      y: 90,
      width: 160,
      height: 160,
      rotation: 0,
      opacity: 1,
      fill: currentBrief.basket.colorPalette[2]?.hex || '#1E293B',
      stroke: currentBrief.basket.colorPalette[0]?.hex || '#F59E0B',
      strokeWidth: 4,
      zIndex: 1
    },
    {
      id: 'init-shape-2',
      type: 'shape',
      shapeType: 'ring',
      x: 140,
      y: 70,
      width: 200,
      height: 200,
      rotation: 0,
      opacity: 0.5,
      fill: currentBrief.basket.colorPalette[1]?.hex || '#10B981',
      stroke: 'transparent',
      strokeWidth: 0,
      zIndex: 2
    },
    {
      id: 'init-text-wordmark',
      type: 'text',
      x: 60,
      y: 300,
      width: 360,
      height: 40,
      rotation: 0,
      opacity: 1,
      fill: currentBrief.basket.colorPalette[3]?.hex || '#FEF3C7',
      stroke: 'transparent',
      strokeWidth: 0,
      text: currentBrief.brandName,
      fontFamily: 'Syne',
      fontSize: 24,
      fontWeight: 800,
      letterSpacing: 4,
      textTransform: 'uppercase',
      zIndex: 3
    },
    {
      id: 'init-text-tagline',
      type: 'text',
      x: 80,
      y: 340,
      width: 320,
      height: 25,
      rotation: 0,
      opacity: 0.7,
      fill: currentBrief.basket.colorPalette[0]?.hex || '#F59E0B',
      stroke: 'transparent',
      strokeWidth: 0,
      text: currentBrief.tagline,
      fontFamily: 'Plus Jakarta Sans',
      fontSize: 10,
      fontWeight: 600,
      letterSpacing: 2,
      textTransform: 'uppercase',
      zIndex: 4
    }
  ]);

  const [userRationale, setUserRationale] = useState<string>(
    `Crafted a high-contrast circular emblem uniting the ${currentBrief.basket.symbolMotif.title} with the ${currentBrief.basket.paradoxConstraint.title}.`
  );

  // Rivals data
  const [rivals, setRivals] = useState<Designer[]>(() => getRivalDesigners(currentBrief));

  // User vote tracking in live audience voting
  const [userVotedId, setUserVotedId] = useState<string | null>(null);

  // Crowned winner for podium finale
  const [crownedWinner, setCrownedWinner] = useState<Designer | null>(null);

  // When changing brief, reset canvas and rivals
  const handleSelectBrief = (newBrief: MysteryBrief) => {
    setCurrentBrief(newBrief);
    setSecondsLeft(TOTAL_SECONDS);
    setTwistTriggered(false);
    setUserVotedId(null);
    setCrownedWinner(null);
    setRivals(getRivalDesigners(newBrief));

    // Reset user canvas to new brief palette and name
    setUserElements([
      {
        id: 'init-shape-1',
        type: 'shape',
        shapeType: 'circle',
        x: 160,
        y: 90,
        width: 160,
        height: 160,
        rotation: 0,
        opacity: 1,
        fill: newBrief.basket.colorPalette[2]?.hex || '#1E293B',
        stroke: newBrief.basket.colorPalette[0]?.hex || '#F59E0B',
        strokeWidth: 4,
        zIndex: 1
      },
      {
        id: 'init-shape-2',
        type: 'shape',
        shapeType: 'ring',
        x: 140,
        y: 70,
        width: 200,
        height: 200,
        rotation: 0,
        opacity: 0.5,
        fill: newBrief.basket.colorPalette[1]?.hex || '#10B981',
        stroke: 'transparent',
        strokeWidth: 0,
        zIndex: 2
      },
      {
        id: 'init-text-wordmark',
        type: 'text',
        x: 60,
        y: 300,
        width: 360,
        height: 40,
        rotation: 0,
        opacity: 1,
        fill: newBrief.basket.colorPalette[3]?.hex || '#FFFFFF',
        stroke: 'transparent',
        strokeWidth: 0,
        text: newBrief.brandName,
        fontFamily: 'Syne',
        fontSize: 24,
        fontWeight: 800,
        letterSpacing: 4,
        textTransform: 'uppercase',
        zIndex: 3
      },
      {
        id: 'init-text-tagline',
        type: 'text',
        x: 80,
        y: 340,
        width: 320,
        height: 25,
        rotation: 0,
        opacity: 0.7,
        fill: newBrief.basket.colorPalette[0]?.hex || '#F59E0B',
        stroke: 'transparent',
        strokeWidth: 0,
        text: newBrief.tagline,
        fontFamily: 'Plus Jakarta Sans',
        fontSize: 10,
        fontWeight: 600,
        letterSpacing: 2,
        textTransform: 'uppercase',
        zIndex: 4
      }
    ]);

    setUserRationale(
      `Engineered a focused vector lockup balancing the ${newBrief.basket.symbolMotif.title} with clean typography.`
    );
    setCurrentPhase('SPRINT_ACTIVE');
    setActiveTab('arena');
  };

  // Toggle Mute
  const handleToggleMute = () => {
    const nextState = !isMuted;
    setIsMuted(nextState);
    sound.enabled = !nextState;
  };

  // 60-Minute Countdown Clock Hook
  useEffect(() => {
    if (!isTimerRunning || currentPhase !== 'SPRINT_ACTIVE') return;

    const interval = setInterval(() => {
      setSecondsLeft((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          sound.buzzer();
          setCurrentPhase('TIME_UP_PRESENTATION');
          setActiveTab('voting');
          return 0;
        }

        const next = Math.max(0, prev - speedMultiplier);

        // Check if hitting the 30-minute twist point (1800 seconds)
        if (next <= 1800 && prev > 1800 && !twistTriggered) {
          setTwistTriggered(true);
          setShowTwistModal(true);
          sound.twistSiren();
        }

        return next;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isTimerRunning, speedMultiplier, currentPhase, twistTriggered]);

  // Manually trigger twist early
  const triggerTwistEarly = () => {
    setTwistTriggered(true);
    setShowTwistModal(true);
  };

  // Consolidated all designers array (User is Station 1)
  const allDesigners: Designer[] = [
    {
      id: 'station-1',
      stationNumber: 1,
      name: 'You (Player)',
      title: 'Principal Designer · Station 1',
      isUser: true,
      avatarSeed: 'user',
      styleSchool: 'Contemporary Identity System',
      bio: 'Station 1 contestant tackling the Chopped mystery basket under intense live studio pressure.',
      currentThought: 'Refining the visual hierarchy to pass the judges’ 16px favicon scale test.',
      elements: userElements,
      rationale: userRationale,
      audienceVotes: 36,
      twistIntegrated: twistTriggered,
      isChopped: false,
      critique: {
        judgeScores: {
          creativity: 94,
          compliance: 95,
          craft: 93,
          presentation: 92
        },
        verdict: 'Masterful interpretation of the paradoxical brief. Clean, bold vector geometry that commands attention.',
        highlights: ['Flawless scale balance', 'Thoughtful negative space usage', 'Creative basket adherence'],
        weakness: 'Ensure sufficient optical clearance between secondary type and the primary mark.'
      }
    },
    ...rivals
  ];

  // Cast vote in Audience View
  const handleCastVote = (designerId: string) => {
    setUserVotedId(designerId);
    setRivals((prev) =>
      prev.map((r) =>
        r.id === designerId ? { ...r, audienceVotes: r.audienceVotes + 1 } : r
      )
    );
  };

  // User object for mockups
  const userDesigner = allDesigners[0];
  const activeWinner = crownedWinner || userDesigner;

  return (
    <div className="flex flex-col h-screen w-screen overflow-hidden bg-neutral-950 text-neutral-100 font-sans select-none">
      {/* 3-Zone Top Bar Contract */}
      <TopBar
        currentPhase={currentPhase}
        onNavigate={(tab) => {
          sound.pop();
          setActiveTab(tab);
        }}
        activeTab={activeTab}
        isMuted={isMuted}
        onToggleMute={handleToggleMute}
        onOpenNewBriefModal={() => setShowNewBriefModal(true)}
      />

      {/* Chopped 60-Minute Countdown HUD */}
      <SprintHUD
        secondsLeft={secondsLeft}
        totalSeconds={TOTAL_SECONDS}
        isRunning={isTimerRunning}
        onTogglePlay={() => setIsTimerRunning(!isTimerRunning)}
        onFastForward={(mult) => setSpeedMultiplier(mult)}
        speedMultiplier={speedMultiplier}
        currentPhase={currentPhase}
        onAdvancePhase={(next) => {
          setCurrentPhase(next);
          if (next === 'TIME_UP_PRESENTATION' || next === 'AUDIENCE_VOTING') {
            setActiveTab('voting');
          } else if (next === 'JUDGES_CHOP') {
            setActiveTab('judges');
          } else if (next === 'FINALE_PODIUM') {
            setActiveTab('mockups');
          }
        }}
        brief={currentBrief}
        twistTriggered={twistTriggered}
        onTriggerTwistEarly={triggerTwistEarly}
      />

      {/* Main Viewport Router */}
      <main className="flex-1 flex overflow-hidden relative">
        {/* 1. Design Arena (Interactive Vector Canvas Workbench) */}
        {activeTab === 'arena' && (
          <CanvasEditor
            elements={userElements}
            onChangeElements={setUserElements}
            brief={currentBrief}
            rationale={userRationale}
            onChangeRationale={setUserRationale}
            onOpenMockupPreview={() => setActiveTab('mockups')}
          />
        )}

        {/* 2. Rival Stations (Live AI Competitor Workstations) */}
        {activeTab === 'rivals' && (
          <RivalStations
            rivals={rivals}
            brief={currentBrief}
            twistTriggered={twistTriggered}
          />
        )}

        {/* 3. Mystery Basket Brief Unveiling */}
        {activeTab === 'brief' && (
          <MysteryBasketView
            brief={currentBrief}
            onSelectBrief={handleSelectBrief}
            twistTriggered={twistTriggered}
            onStartSprint={() => setActiveTab('arena')}
          />
        )}

        {/* 4. Live Audience Voting & Broadcast Chat Stream */}
        {activeTab === 'voting' && (
          <AudienceVotingView
            designers={allDesigners}
            brief={currentBrief}
            onCastVote={handleCastVote}
            userVotedId={userVotedId}
            onProceedToJudges={() => {
              setCurrentPhase('JUDGES_CHOP');
              setActiveTab('judges');
            }}
          />
        )}

        {/* 5. The Chopping Block & Judges Deliberation */}
        {activeTab === 'judges' && (
          <ChoppingBlock
            designers={allDesigners}
            brief={currentBrief}
            onAdvanceToFinale={(winner) => {
              setCrownedWinner(winner);
              setCurrentPhase('FINALE_PODIUM');
              setActiveTab('mockups');
            }}
          />
        )}

        {/* 6. Real-World Mockup Gallery & Champion Podium */}
        {activeTab === 'mockups' && (
          <MockupPreview
            designer={activeWinner}
            brief={currentBrief}
            onRestartSprint={() => {
              handleSelectBrief(currentBrief);
            }}
          />
        )}
      </main>

      {/* Surprise Mid-Round Twist Interruption Modal */}
      <TwistModal
        brief={currentBrief}
        isOpen={showTwistModal}
        onClose={() => setShowTwistModal(false)}
      />

      {/* Switch Brief / Mystery Basket Modal */}
      <NewBriefModal
        isOpen={showNewBriefModal}
        onClose={() => setShowNewBriefModal(false)}
        onSelectBrief={handleSelectBrief}
        activeBriefId={currentBrief.id}
      />
    </div>
  );
}
