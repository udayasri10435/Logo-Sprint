import React, { useState, useEffect } from 'react';
import {
  Users,
  Send,
  Heart,
  Flame,
  Trophy,
  Zap,
  CheckCircle2,
  TrendingUp,
  MessageSquare
} from 'lucide-react';
import { Designer, MysteryBrief, AudienceComment } from '../types';
import { renderShapeSvg } from '../utils/vectorPaths';
import { INITIAL_AUDIENCE_CHAT } from '../data/briefs';
import { sound } from '../utils/audio';

interface AudienceVotingViewProps {
  designers: Designer[];
  brief: MysteryBrief;
  onCastVote: (designerId: string) => void;
  userVotedId: string | null;
  onProceedToJudges: () => void;
}

interface FloatingEmoji {
  id: number;
  emoji: string;
  x: number;
  y: number;
}

export const AudienceVotingView: React.FC<AudienceVotingViewProps> = ({
  designers,
  brief,
  onCastVote,
  userVotedId,
  onProceedToJudges
}) => {
  const [chatMessages, setChatMessages] = useState<AudienceComment[]>(
    INITIAL_AUDIENCE_CHAT.map((c, i) => ({
      id: 'init-' + i,
      username: c.username,
      avatarColor: c.color,
      text: c.text,
      timestamp: 'just now',
      badge: c.badge
    }))
  );
  const [myComment, setMyComment] = useState<string>('');
  const [floatingEmojis, setFloatingEmojis] = useState<FloatingEmoji[]>([]);
  const [viewerCount, setViewerCount] = useState<number>(2418);

  // Calculate total votes and percentage
  const totalVotes = designers.reduce((acc, d) => acc + d.audienceVotes, 0);

  // Periodically add hilarious simulated community chat comments
  useEffect(() => {
    const funnyComments = [
      'Station 1 really understood the assignment with that negative space!',
      'Did Station 3 completely forget the canary feather twist?! lol',
      'The typography on Station 2 gives pure Swiss perfection',
      'I would buy a t-shirt with Station 4’s badge tomorrow morning',
      'Helena is gonna eviscerate someone in 5 minutes',
      'Audience votes are neck and neck right now!',
      'VOTED! That palette integration is elite 🔥',
      'Look at that color balance on the wordmark',
      'Can we get this brand into real life already??'
    ];

    const interval = setInterval(() => {
      const randomText = funnyComments[Math.floor(Math.random() * funnyComments.length)];
      const randomUser = `Viewer_${Math.floor(100 + Math.random() * 900)}`;
      const colors = ['#F59E0B', '#10B981', '#3B82F6', '#EC4899', '#8B5CF6'];
      const randomColor = colors[Math.floor(Math.random() * colors.length)];

      setChatMessages((prev) => [
        ...prev.slice(-15),
        {
          id: 'chat-' + Date.now(),
          username: randomUser,
          avatarColor: randomColor,
          text: randomText,
          timestamp: 'now'
        }
      ]);
      setViewerCount((v) => v + Math.floor(Math.random() * 5 - 2));
    }, 4500);

    return () => clearInterval(interval);
  }, []);

  // Post user comment
  const handleSendComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!myComment.trim()) return;
    sound.pop();
    setChatMessages((prev) => [
      ...prev,
      {
        id: 'user-' + Date.now(),
        username: 'You (VIP Critic)',
        avatarColor: '#F59E0B',
        text: myComment.trim(),
        timestamp: 'just now',
        badge: 'VIP'
      }
    ]);
    setMyComment('');
  };

  // Trigger floating reaction burst
  const triggerReaction = (emoji: string) => {
    sound.pop();
    const newEmoji: FloatingEmoji = {
      id: Date.now() + Math.random(),
      emoji,
      x: 30 + Math.random() * 40,
      y: 90
    };
    setFloatingEmojis((prev) => [...prev, newEmoji]);
    setTimeout(() => {
      setFloatingEmojis((prev) => prev.filter((item) => item.id !== newEmoji.id));
    }, 1800);
  };

  return (
    <div className="flex-1 overflow-hidden flex flex-col lg:flex-row bg-neutral-950 relative">
      {/* Floating Emojis Overlay */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden z-30">
        {floatingEmojis.map((item) => (
          <div
            key={item.id}
            className="absolute text-3xl animate-bounce"
            style={{
              left: `${item.x}%`,
              bottom: '20%',
              transition: 'all 1.5s ease-out',
              transform: 'translateY(-120px) scale(1.3)',
              opacity: 0.9
            }}
          >
            {item.emoji}
          </div>
        ))}
      </div>

      {/* Main Voting Grid */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-neutral-800 pb-4">
          <div>
            <div className="text-xs uppercase font-mono tracking-wider text-amber-400 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
              <span>LIVE AUDIENCE BROADCAST & VOTING</span>
            </div>
            <h2 className="font-display text-2xl md:text-3xl font-bold text-white tracking-tight mt-0.5">
              Audience Choice Ballot
            </h2>
            <p className="text-xs text-neutral-400 mt-1">
              Over {viewerCount.toLocaleString()} live viewers are casting votes for the best identity for "{brief.brandName}".
            </p>
          </div>

          <div className="flex items-center gap-3">
            {/* Quick Reactions Bar */}
            <div className="flex items-center gap-1 bg-neutral-900 border border-neutral-800 p-1 rounded-xl">
              {['🔥', '❤️', '🏆', '⚡', '👏'].map((emoji) => (
                <button
                  key={emoji}
                  onClick={() => triggerReaction(emoji)}
                  className="p-1.5 hover:bg-neutral-800 rounded-lg text-lg transition-transform active:scale-125"
                  title={`React ${emoji}`}
                >
                  {emoji}
                </button>
              ))}
            </div>

            <button
              onClick={() => {
                sound.clocheBell();
                onProceedToJudges();
              }}
              className="px-4 py-2 bg-amber-400 hover:bg-amber-300 text-neutral-950 text-xs font-bold rounded-lg transition-colors whitespace-nowrap shadow-md shadow-amber-500/20"
            >
              Close Polls & Judge
            </button>
          </div>
        </div>

        {/* 4 Contestants Voting Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {designers.map((designer) => {
            const votePercent = totalVotes > 0 ? Math.round((designer.audienceVotes / totalVotes) * 100) : 25;
            const hasVotedThis = userVotedId === designer.id;

            return (
              <div
                key={designer.id}
                className={`bg-neutral-900 rounded-xl border p-5 transition-all relative flex flex-col justify-between ${
                  hasVotedThis
                    ? 'border-amber-400 shadow-xl shadow-amber-500/10 ring-1 ring-amber-400'
                    : 'border-neutral-800 hover:border-neutral-700'
                }`}
              >
                <div>
                  {/* Card Header */}
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-[11px] font-mono font-bold text-amber-400 uppercase">
                          STATION {designer.stationNumber}
                        </span>
                        {designer.isUser && (
                          <span className="text-[10px] px-2 py-0.5 bg-amber-400/20 text-amber-300 rounded font-semibold border border-amber-400/30">
                            YOU
                          </span>
                        )}
                      </div>
                      <h3 className="font-display text-lg font-bold text-white mt-0.5">
                        {designer.name}
                      </h3>
                      <div className="text-xs text-neutral-400">
                        {designer.styleSchool}
                      </div>
                    </div>

                    <div className="text-right">
                      <div className="font-mono tabular-nums text-2xl font-black text-amber-400">
                        {votePercent}%
                      </div>
                      <div className="text-[10px] text-neutral-400 uppercase">
                        {designer.audienceVotes} Votes
                      </div>
                    </div>
                  </div>

                  {/* Logo Canvas Mini Preview */}
                  <div className="w-full aspect-[4/3] bg-neutral-950 rounded-lg border border-neutral-800 p-3 mb-4 flex items-center justify-center relative overflow-hidden">
                    <svg viewBox="0 0 480 480" className="w-full h-full max-h-48">
                      {[...designer.elements]
                        .sort((a, b) => a.zIndex - b.zIndex)
                        .map((el) => (
                          <g
                            key={el.id}
                            transform={`translate(${el.x}, ${el.y}) rotate(${el.rotation} ${el.width / 2} ${el.height / 2})`}
                            opacity={el.opacity}
                          >
                            {el.type === 'shape' && el.shapeType && (
                              renderShapeSvg(
                                el.shapeType,
                                el.width,
                                el.height,
                                el.fill,
                                el.stroke,
                                el.strokeWidth
                              )
                            )}
                            {el.type === 'text' && (
                              <text
                                x={el.width / 2}
                                y={el.height * 0.75}
                                textAnchor="middle"
                                fill={el.fill}
                                stroke={el.stroke}
                                strokeWidth={el.strokeWidth}
                                fontFamily={el.fontFamily || 'Syne'}
                                fontSize={el.fontSize || 24}
                                fontWeight={el.fontWeight || 700}
                                letterSpacing={el.letterSpacing || 2}
                                style={{ textTransform: el.textTransform || 'none' }}
                              >
                                {el.text}
                              </text>
                            )}
                          </g>
                        ))}
                    </svg>
                  </div>

                  {/* Progress Bar of Audience Share */}
                  <div className="space-y-1.5 mb-4">
                    <div className="w-full h-2.5 bg-neutral-950 rounded-full overflow-hidden border border-neutral-800">
                      <div
                        className="h-full bg-gradient-to-r from-amber-500 to-amber-300 transition-all duration-500"
                        style={{ width: `${votePercent}%` }}
                      />
                    </div>
                  </div>

                  {/* Rationale Snippet */}
                  <p className="text-xs text-neutral-300 italic line-clamp-2 mb-3">
                    "{designer.rationale || 'Focused on balance, tension, and basket ingredient harmony.'}"
                  </p>
                </div>

                {/* Vote Action Button */}
                <button
                  onClick={() => {
                    sound.pop();
                    onCastVote(designer.id);
                  }}
                  className={`w-full py-2 px-3 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-2 ${
                    hasVotedThis
                      ? 'bg-emerald-500 text-neutral-950'
                      : 'bg-neutral-800 hover:bg-amber-400 hover:text-neutral-950 text-neutral-200'
                  }`}
                >
                  {hasVotedThis ? (
                    <>
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Your Ballot Cast Here!</span>
                    </>
                  ) : (
                    <>
                      <Trophy className="w-4 h-4" />
                      <span>Vote for Station {designer.stationNumber}</span>
                    </>
                  )}
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* Right: Live Stream Chat Stream */}
      <div className="w-full lg:w-80 bg-neutral-900 border-t lg:border-t-0 lg:border-l border-neutral-800 flex flex-col h-80 lg:h-full">
        <div className="p-3 border-b border-neutral-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <MessageSquare className="w-4 h-4 text-amber-400" />
            <span className="font-mono text-xs font-bold uppercase text-white">
              Live Stream Chat
            </span>
          </div>
          <span className="text-[11px] text-neutral-400 font-mono flex items-center gap-1">
            <Users className="w-3.5 h-3.5 text-emerald-400" />
            <span>{viewerCount.toLocaleString()}</span>
          </span>
        </div>

        {/* Chat Messages */}
        <div className="flex-1 overflow-y-auto p-3 space-y-2.5 text-xs">
          {chatMessages.map((msg) => (
            <div key={msg.id} className="leading-relaxed break-words">
              <span
                className="font-bold mr-1.5"
                style={{ color: msg.avatarColor }}
              >
                {msg.username}
                {msg.badge && (
                  <span className="ml-1 text-[9px] px-1 py-0.2 bg-neutral-800 text-neutral-300 rounded font-mono">
                    {msg.badge}
                  </span>
                )}
                :
              </span>
              <span className="text-neutral-300">{msg.text}</span>
            </div>
          ))}
        </div>

        {/* User Chat Input */}
        <form
          onSubmit={handleSendComment}
          className="p-3 border-t border-neutral-800 flex items-center gap-2 bg-neutral-950"
        >
          <input
            type="text"
            value={myComment}
            onChange={(e) => setMyComment(e.target.value)}
            placeholder="Send message to live audience..."
            className="flex-1 px-3 py-1.5 bg-neutral-900 border border-neutral-800 rounded-lg text-xs text-neutral-100 placeholder-neutral-500 focus:outline-none focus:border-amber-400"
          />
          <button
            type="submit"
            className="p-2 bg-amber-400 hover:bg-amber-300 text-neutral-950 rounded-lg transition-colors"
            title="Send chat"
          >
            <Send className="w-3.5 h-3.5" />
          </button>
        </form>
      </div>
    </div>
  );
};
