import React, { useState, useRef, useEffect } from 'react';
import {
  Square,
  Circle,
  Type,
  Trash2,
  Copy,
  ArrowUp,
  ArrowDown,
  RotateCw,
  Sparkles,
  Download,
  Code,
  Palette,
  Eye,
  Grid,
  Maximize2,
  RefreshCw,
  Plus
} from 'lucide-react';
import { CanvasElement, MysteryBrief, ShapeType } from '../types';
import { MOTIF_LIBRARY, MotifDefinition, renderShapeSvg } from '../utils/vectorPaths';
import { sound } from '../utils/audio';

interface CanvasEditorProps {
  elements: CanvasElement[];
  onChangeElements: (elements: CanvasElement[]) => void;
  brief: MysteryBrief;
  rationale: string;
  onChangeRationale: (text: string) => void;
  onOpenMockupPreview: () => void;
}

export const CanvasEditor: React.FC<CanvasEditorProps> = ({
  elements,
  onChangeElements,
  brief,
  rationale,
  onChangeRationale,
  onOpenMockupPreview
}) => {
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [activeTool, setActiveTool] = useState<'shapes' | 'text' | 'motifs' | 'library'>('shapes');
  const [isLightMode, setIsLightMode] = useState<boolean>(false);
  const [showGrid, setShowGrid] = useState<boolean>(true);
  const [copyCodeSuccess, setCopyCodeSuccess] = useState<boolean>(false);

  // Dragging state
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [dragOffset, setDragOffset] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const svgRef = useRef<SVGSVGElement | null>(null);

  const selectedElement = elements.find((el) => el.id === selectedId) || null;

  // Add a shape
  const addShape = (shapeType: ShapeType) => {
    sound.pop();
    const primaryColor = brief.basket.colorPalette[0]?.hex || '#F59E0B';
    const newElement: CanvasElement = {
      id: 'shape-' + Date.now(),
      type: 'shape',
      shapeType,
      x: 150 + Math.random() * 40,
      y: 150 + Math.random() * 40,
      width: 120,
      height: 120,
      rotation: 0,
      opacity: 1,
      fill: primaryColor,
      stroke: 'transparent',
      strokeWidth: 0,
      zIndex: elements.length + 1
    };
    onChangeElements([...elements, newElement]);
    setSelectedId(newElement.id);
  };

  // Add text
  const addText = (textValue: string, isBrandName = false) => {
    sound.pop();
    const textColor = brief.basket.colorPalette[3]?.hex || '#FFFFFF';
    const newElement: CanvasElement = {
      id: 'text-' + Date.now(),
      type: 'text',
      x: 100,
      y: isBrandName ? 280 : 330,
      width: 280,
      height: 40,
      rotation: 0,
      opacity: 1,
      fill: textColor,
      stroke: 'transparent',
      strokeWidth: 0,
      text: textValue,
      fontFamily: isBrandName ? 'Syne' : 'Plus Jakarta Sans',
      fontSize: isBrandName ? 26 : 12,
      fontWeight: isBrandName ? 800 : 600,
      letterSpacing: isBrandName ? 3 : 2,
      textTransform: 'uppercase',
      zIndex: elements.length + 1
    };
    onChangeElements([...elements, newElement]);
    setSelectedId(newElement.id);
  };

  // Add motif / basket ingredient symbol
  const addMotif = (motif: MotifDefinition) => {
    sound.pop();
    const accentColor = brief.basket.colorPalette[1]?.hex || '#10B981';
    const newElement: CanvasElement = {
      id: 'motif-' + Date.now(),
      type: 'icon',
      iconName: motif.id,
      pathData: motif.path,
      x: 170,
      y: 130,
      width: 120,
      height: 120,
      rotation: 0,
      opacity: 1,
      fill: accentColor,
      stroke: 'transparent',
      strokeWidth: 0,
      zIndex: elements.length + 1
    };
    onChangeElements([...elements, newElement]);
    setSelectedId(newElement.id);
  };

  // Duplicate selected
  const duplicateSelected = () => {
    if (!selectedElement) return;
    sound.pop();
    const copy: CanvasElement = {
      ...selectedElement,
      id: 'dup-' + Date.now(),
      x: selectedElement.x + 20,
      y: selectedElement.y + 20,
      zIndex: elements.length + 1
    };
    onChangeElements([...elements, copy]);
    setSelectedId(copy.id);
  };

  // Delete selected
  const deleteSelected = () => {
    if (!selectedElement) return;
    sound.pop();
    onChangeElements(elements.filter((el) => el.id !== selectedId));
    setSelectedId(null);
  };

  // Layer ordering
  const bringForward = () => {
    if (!selectedElement) return;
    sound.pop();
    const updated = elements.map((el) =>
      el.id === selectedId ? { ...el, zIndex: el.zIndex + 2 } : el
    );
    onChangeElements(updated);
  };

  const sendBackward = () => {
    if (!selectedElement) return;
    sound.pop();
    const updated = elements.map((el) =>
      el.id === selectedId ? { ...el, zIndex: Math.max(1, el.zIndex - 2) } : el
    );
    onChangeElements(updated);
  };

  // Update selected element property
  const updateSelected = (updates: Partial<CanvasElement>) => {
    if (!selectedId) return;
    onChangeElements(
      elements.map((el) => (el.id === selectedId ? { ...el, ...updates } : el))
    );
  };

  // Idea Spark / Preset layout starters
  const loadIdeaSpark = (presetType: 'monogram' | 'badge' | 'modern') => {
    sound.pop();
    const p = brief.basket.colorPalette;
    const c0 = p[0].hex;
    const c1 = p[1].hex;
    const c2 = p[2].hex;
    const c3 = p[3].hex;

    if (presetType === 'monogram') {
      const initial = brief.brandName.charAt(0);
      onChangeElements([
        {
          id: 'preset-bg',
          type: 'shape',
          shapeType: 'circle',
          x: 160,
          y: 90,
          width: 160,
          height: 160,
          rotation: 0,
          opacity: 1,
          fill: c2,
          stroke: c0,
          strokeWidth: 4,
          zIndex: 1
        },
        {
          id: 'preset-ring',
          type: 'shape',
          shapeType: 'ring',
          x: 140,
          y: 70,
          width: 200,
          height: 200,
          rotation: 0,
          opacity: 0.6,
          fill: c1,
          stroke: 'transparent',
          strokeWidth: 0,
          zIndex: 2
        },
        {
          id: 'preset-letter',
          type: 'text',
          x: 170,
          y: 110,
          width: 140,
          height: 120,
          rotation: 0,
          opacity: 1,
          fill: c3,
          stroke: 'transparent',
          strokeWidth: 0,
          text: initial,
          fontFamily: 'Syne',
          fontSize: 84,
          fontWeight: 800,
          zIndex: 3
        },
        {
          id: 'preset-wordmark',
          type: 'text',
          x: 60,
          y: 300,
          width: 360,
          height: 40,
          rotation: 0,
          opacity: 1,
          fill: c3,
          stroke: 'transparent',
          strokeWidth: 0,
          text: brief.brandName,
          fontFamily: 'Syne',
          fontSize: 24,
          fontWeight: 800,
          letterSpacing: 4,
          textTransform: 'uppercase',
          zIndex: 4
        },
        {
          id: 'preset-tagline',
          type: 'text',
          x: 80,
          y: 340,
          width: 320,
          height: 25,
          rotation: 0,
          opacity: 0.75,
          fill: c0,
          stroke: 'transparent',
          strokeWidth: 0,
          text: brief.tagline,
          fontFamily: 'Plus Jakarta Sans',
          fontSize: 10,
          fontWeight: 600,
          letterSpacing: 2,
          textTransform: 'uppercase',
          zIndex: 5
        }
      ]);
    } else if (presetType === 'badge') {
      onChangeElements([
        {
          id: 'badge-shield',
          type: 'shape',
          shapeType: 'shield',
          x: 140,
          y: 80,
          width: 200,
          height: 200,
          rotation: 0,
          opacity: 1,
          fill: c2,
          stroke: c0,
          strokeWidth: 6,
          zIndex: 1
        },
        {
          id: 'badge-star',
          type: 'shape',
          shapeType: 'star',
          x: 205,
          y: 110,
          width: 70,
          height: 70,
          rotation: 0,
          opacity: 1,
          fill: c1,
          stroke: 'transparent',
          strokeWidth: 0,
          zIndex: 2
        },
        {
          id: 'badge-word',
          type: 'text',
          x: 90,
          y: 310,
          width: 300,
          height: 40,
          rotation: 0,
          opacity: 1,
          fill: c3,
          stroke: 'transparent',
          strokeWidth: 0,
          text: brief.brandName,
          fontFamily: 'JetBrains Mono',
          fontSize: 22,
          fontWeight: 800,
          letterSpacing: 2,
          textTransform: 'uppercase',
          zIndex: 3
        }
      ]);
    } else {
      onChangeElements([
        {
          id: 'mod-pill',
          type: 'shape',
          shapeType: 'pill',
          x: 150,
          y: 110,
          width: 180,
          height: 60,
          rotation: -15,
          opacity: 1,
          fill: c0,
          stroke: 'transparent',
          strokeWidth: 0,
          zIndex: 1
        },
        {
          id: 'mod-circle',
          type: 'shape',
          shapeType: 'circle',
          x: 230,
          y: 120,
          width: 100,
          height: 100,
          rotation: 0,
          opacity: 0.9,
          fill: c1,
          stroke: c2,
          strokeWidth: 4,
          zIndex: 2
        },
        {
          id: 'mod-text',
          type: 'text',
          x: 80,
          y: 300,
          width: 320,
          height: 40,
          rotation: 0,
          opacity: 1,
          fill: c3,
          stroke: 'transparent',
          strokeWidth: 0,
          text: brief.brandName,
          fontFamily: 'Syne',
          fontSize: 24,
          fontWeight: 800,
          letterSpacing: 5,
          textTransform: 'uppercase',
          zIndex: 3
        }
      ]);
    }
  };

  // Mouse & Drag handlers on canvas
  const handleMouseDown = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    setSelectedId(id);
    setIsDragging(true);

    if (svgRef.current) {
      const rect = svgRef.current.getBoundingClientRect();
      const scaleX = 480 / rect.width;
      const scaleY = 480 / rect.height;
      const mouseX = (e.clientX - rect.left) * scaleX;
      const mouseY = (e.clientY - rect.top) * scaleY;

      const el = elements.find((item) => item.id === id);
      if (el) {
        setDragOffset({
          x: mouseX - el.x,
          y: mouseY - el.y
        });
      }
    }
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging || !selectedId || !svgRef.current) return;

    const rect = svgRef.current.getBoundingClientRect();
    const scaleX = 480 / rect.width;
    const scaleY = 480 / rect.height;
    const mouseX = (e.clientX - rect.left) * scaleX;
    const mouseY = (e.clientY - rect.top) * scaleY;

    const newX = Math.round(mouseX - dragOffset.x);
    const newY = Math.round(mouseY - dragOffset.y);

    updateSelected({ x: newX, y: newY });
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  // Keyboard navigation & delete
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!selectedId) return;
      // Don't trigger if user is typing in a textarea or text input
      if (['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement).tagName)) return;

      if (e.key === 'Backspace' || e.key === 'Delete') {
        e.preventDefault();
        deleteSelected();
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        updateSelected({ y: (selectedElement?.y || 0) - (e.shiftKey ? 10 : 2) });
      } else if (e.key === 'ArrowDown') {
        e.preventDefault();
        updateSelected({ y: (selectedElement?.y || 0) + (e.shiftKey ? 10 : 2) });
      } else if (e.key === 'ArrowLeft') {
        e.preventDefault();
        updateSelected({ x: (selectedElement?.x || 0) - (e.shiftKey ? 10 : 2) });
      } else if (e.key === 'ArrowRight') {
        e.preventDefault();
        updateSelected({ x: (selectedElement?.x || 0) + (e.shiftKey ? 10 : 2) });
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedId, elements]);

  // Copy SVG Code
  const copySvgCode = () => {
    if (!svgRef.current) return;
    const serializer = new XMLSerializer();
    const svgStr = serializer.serializeToString(svgRef.current);
    navigator.clipboard.writeText(svgStr).then(() => {
      setCopyCodeSuccess(true);
      setTimeout(() => setCopyCodeSuccess(false), 2000);
    });
  };

  // Download SVG file
  const downloadSvgFile = () => {
    if (!svgRef.current) return;
    const serializer = new XMLSerializer();
    const svgStr = serializer.serializeToString(svgRef.current);
    const blob = new Blob([svgStr], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${brief.brandName.toLowerCase().replace(/\s+/g, '-')}-logo.svg`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex-1 flex flex-col xl:flex-row overflow-hidden bg-neutral-950">
      {/* Left Design Tools Sidebar */}
      <div className="w-full xl:w-72 bg-neutral-900 border-b xl:border-b-0 xl:border-r border-neutral-800 flex flex-col p-4 gap-4 overflow-y-auto max-h-[35vh] xl:max-h-full">
        {/* Tool Category Tabs */}
        <div className="flex items-center gap-1 p-1 bg-neutral-950 rounded-lg border border-neutral-800">
          <button
            onClick={() => setActiveTool('shapes')}
            className={`flex-1 py-1.5 px-2 text-xs font-semibold rounded-md transition-colors ${
              activeTool === 'shapes' ? 'bg-neutral-800 text-white' : 'text-neutral-400 hover:text-white'
            }`}
          >
            Shapes
          </button>
          <button
            onClick={() => setActiveTool('motifs')}
            className={`flex-1 py-1.5 px-2 text-xs font-semibold rounded-md transition-colors ${
              activeTool === 'motifs' ? 'bg-neutral-800 text-white' : 'text-neutral-400 hover:text-white'
            }`}
          >
            Basket Motifs
          </button>
          <button
            onClick={() => setActiveTool('text')}
            className={`flex-1 py-1.5 px-2 text-xs font-semibold rounded-md transition-colors ${
              activeTool === 'text' ? 'bg-neutral-800 text-white' : 'text-neutral-400 hover:text-white'
            }`}
          >
            Typography
          </button>
        </div>

        {/* Category: Shapes */}
        {activeTool === 'shapes' && (
          <div className="space-y-3">
            <div className="text-xs uppercase font-mono tracking-wider text-neutral-400 flex justify-between items-center">
              <span>Vector Geometry</span>
              <span className="text-[10px] text-neutral-500">Click to add</span>
            </div>
            <div className="grid grid-cols-4 gap-2">
              {[
                { type: 'circle', label: 'Circle' },
                { type: 'rect', label: 'Square' },
                { type: 'pill', label: 'Pill' },
                { type: 'triangle', label: 'Triangle' },
                { type: 'diamond', label: 'Diamond' },
                { type: 'hexagon', label: 'Hexagon' },
                { type: 'star', label: 'Star' },
                { type: 'shield', label: 'Shield' },
                { type: 'ring', label: 'Ring' },
                { type: 'cross', label: 'Cross' },
                { type: 'blob', label: 'Blob' },
                { type: 'wave', label: 'Wave' }
              ].map((item) => (
                <button
                  key={item.type}
                  onClick={() => addShape(item.type as ShapeType)}
                  className="flex flex-col items-center justify-center p-2.5 rounded-lg bg-neutral-950 border border-neutral-800 hover:border-amber-400/50 hover:bg-neutral-800 transition-colors group"
                  title={`Add ${item.label}`}
                >
                  <div className="w-6 h-6 flex items-center justify-center text-neutral-300 group-hover:text-amber-400">
                    <svg viewBox="0 0 100 100" className="w-5 h-5">
                      {renderShapeSvg(item.type, 100, 100, 'currentColor', 'transparent', 0)}
                    </svg>
                  </div>
                  <span className="text-[10px] text-neutral-400 mt-1 truncate max-w-full">
                    {item.label}
                  </span>
                </button>
              ))}
            </div>

            {/* Idea Starters */}
            <div className="pt-3 border-t border-neutral-800">
              <span className="text-xs font-mono text-neutral-400 uppercase tracking-wider block mb-2">
                Fast Idea Starters
              </span>
              <div className="grid grid-cols-3 gap-1.5">
                <button
                  onClick={() => loadIdeaSpark('monogram')}
                  className="px-2 py-1.5 bg-neutral-950 hover:bg-neutral-800 border border-neutral-800 text-[11px] font-medium text-neutral-300 rounded transition-colors text-center"
                >
                  Monogram
                </button>
                <button
                  onClick={() => loadIdeaSpark('badge')}
                  className="px-2 py-1.5 bg-neutral-950 hover:bg-neutral-800 border border-neutral-800 text-[11px] font-medium text-neutral-300 rounded transition-colors text-center"
                >
                  Shield Crest
                </button>
                <button
                  onClick={() => loadIdeaSpark('modern')}
                  className="px-2 py-1.5 bg-neutral-950 hover:bg-neutral-800 border border-neutral-800 text-[11px] font-medium text-neutral-300 rounded transition-colors text-center"
                >
                  Asymmetric
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Category: Motifs */}
        {activeTool === 'motifs' && (
          <div className="space-y-3">
            <div className="text-xs uppercase font-mono tracking-wider text-neutral-400 flex justify-between items-center">
              <span>Mystery Basket Motifs</span>
              <span className="text-[10px] text-amber-400">Mandatory</span>
            </div>
            <div className="grid grid-cols-3 gap-2 max-h-72 overflow-y-auto pr-1">
              {MOTIF_LIBRARY.map((motif) => (
                <button
                  key={motif.id}
                  onClick={() => addMotif(motif)}
                  className="flex flex-col items-center justify-center p-2 rounded-lg bg-neutral-950 border border-neutral-800 hover:border-amber-400/50 hover:bg-neutral-800 transition-colors group"
                  title={`Add ${motif.name}`}
                >
                  <svg viewBox={motif.viewBox} className="w-6 h-6 fill-current text-neutral-300 group-hover:text-amber-400">
                    <path d={motif.path} />
                  </svg>
                  <span className="text-[10px] text-neutral-400 mt-1 truncate max-w-full text-center">
                    {motif.name}
                  </span>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Category: Text */}
        {activeTool === 'text' && (
          <div className="space-y-3">
            <div className="text-xs uppercase font-mono tracking-wider text-neutral-400">
              Typography Elements
            </div>
            <div className="space-y-2">
              <button
                onClick={() => addText(brief.brandName, true)}
                className="w-full text-left p-2.5 rounded-lg bg-neutral-950 border border-neutral-800 hover:border-amber-400 hover:bg-neutral-800 transition-colors flex items-center justify-between"
              >
                <div>
                  <div className="text-xs font-bold text-white uppercase tracking-wider">
                    Add Brand Wordmark
                  </div>
                  <div className="text-[11px] text-neutral-400 font-display">
                    "{brief.brandName}"
                  </div>
                </div>
                <Plus className="w-4 h-4 text-amber-400" />
              </button>

              <button
                onClick={() => addText(brief.tagline, false)}
                className="w-full text-left p-2.5 rounded-lg bg-neutral-950 border border-neutral-800 hover:border-amber-400 hover:bg-neutral-800 transition-colors flex items-center justify-between"
              >
                <div>
                  <div className="text-xs font-bold text-white uppercase tracking-wider">
                    Add Tagline Subtext
                  </div>
                  <div className="text-[11px] text-neutral-400 truncate max-w-[170px]">
                    "{brief.tagline}"
                  </div>
                </div>
                <Plus className="w-4 h-4 text-amber-400" />
              </button>

              <button
                onClick={() => addText(brief.brandName.charAt(0), true)}
                className="w-full text-left p-2.5 rounded-lg bg-neutral-950 border border-neutral-800 hover:border-amber-400 hover:bg-neutral-800 transition-colors flex items-center justify-between"
              >
                <div>
                  <div className="text-xs font-bold text-white uppercase tracking-wider">
                    Add Giant Monogram
                  </div>
                  <div className="text-[11px] text-neutral-400">
                    Single Initial "{brief.brandName.charAt(0)}"
                  </div>
                </div>
                <Plus className="w-4 h-4 text-amber-400" />
              </button>
            </div>
          </div>
        )}

        {/* Mandatory Basket Palette Quick Swatches */}
        <div className="pt-3 border-t border-neutral-800">
          <div className="text-xs uppercase font-mono tracking-wider text-neutral-400 flex justify-between items-center mb-2">
            <span>Basket Palette</span>
            <span className="text-[10px] text-amber-400">4 Colors</span>
          </div>
          <div className="grid grid-cols-4 gap-2">
            {brief.basket.colorPalette.map((col, idx) => (
              <button
                key={idx}
                onClick={() => {
                  if (selectedElement) {
                    sound.pop();
                    updateSelected({ fill: col.hex });
                  }
                }}
                className="group relative flex flex-col items-center"
                title={`${col.name} (${col.hex}) - Click to apply to selected`}
              >
                <div
                  className="w-full h-8 rounded-md border border-neutral-700 group-hover:scale-105 transition-transform shadow-sm"
                  style={{ backgroundColor: col.hex }}
                />
                <span className="text-[9px] text-neutral-400 mt-1 truncate max-w-full text-center">
                  {col.name.split(' ')[0]}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Concept Rationale Box (Judges read this!) */}
        <div className="pt-3 border-t border-neutral-800">
          <label className="text-xs uppercase font-mono tracking-wider text-neutral-400 block mb-1.5">
            Station 1 Rationale (For Judges)
          </label>
          <textarea
            value={rationale}
            onChange={(e) => onChangeRationale(e.target.value)}
            placeholder="Explain how your logo resolves the basket paradox & surprise twist..."
            className="w-full h-20 p-2 text-xs bg-neutral-950 border border-neutral-800 rounded-lg text-neutral-200 focus:outline-none focus:border-amber-400 resize-none font-sans"
          />
        </div>
      </div>

      {/* Main Canvas Workspace */}
      <div className="flex-1 flex flex-col bg-neutral-950 relative min-h-[480px]">
        {/* Canvas Toolbar Header */}
        <div className="px-6 py-2 border-b border-neutral-800 bg-neutral-900/60 flex items-center justify-between text-xs">
          <div className="flex items-center gap-3">
            <span className="font-mono text-neutral-400">STATION 1 · LIVE WORKBENCH</span>
            <span className="text-neutral-600">|</span>
            <span className="text-neutral-400">{elements.length} Elements on Canvas</span>
          </div>

          <div className="flex items-center gap-2">
            {/* Dark / Light toggle */}
            <button
              onClick={() => setIsLightMode(!isLightMode)}
              className={`p-1.5 rounded transition-colors ${
                isLightMode ? 'bg-white text-neutral-900 shadow-sm' : 'text-neutral-400 hover:text-white hover:bg-neutral-800'
              }`}
              title="Toggle Light/Dark Canvas Background"
            >
              <Eye className="w-4 h-4" />
            </button>

            {/* Grid toggle */}
            <button
              onClick={() => setShowGrid(!showGrid)}
              className={`p-1.5 rounded transition-colors ${
                showGrid ? 'bg-neutral-800 text-amber-400' : 'text-neutral-400 hover:text-white hover:bg-neutral-800'
              }`}
              title="Toggle 24px Grid Guidelines"
            >
              <Grid className="w-4 h-4" />
            </button>

            {/* Copy SVG code */}
            <button
              onClick={copySvgCode}
              className="p-1.5 rounded text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
              title="Copy Clean SVG Vector Code"
            >
              <Code className="w-4 h-4" />
            </button>

            {/* Download SVG */}
            <button
              onClick={downloadSvgFile}
              className="p-1.5 rounded text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
              title="Download Logo (.svg)"
            >
              <Download className="w-4 h-4" />
            </button>

            {/* Test on Mockups */}
            <button
              onClick={() => {
                sound.pop();
                onOpenMockupPreview();
              }}
              className="px-2.5 py-1 bg-neutral-800 hover:bg-neutral-700 text-amber-400 rounded font-semibold text-xs transition-colors flex items-center gap-1.5 border border-amber-500/30"
            >
              <Maximize2 className="w-3.5 h-3.5" />
              <span>Preview Mockups</span>
            </button>
          </div>
        </div>

        {/* The SVG Canvas Container */}
        <div
          className={`flex-1 flex items-center justify-center p-6 select-none overflow-hidden ${
            isLightMode ? 'bg-neutral-200' : 'bg-neutral-950'
          }`}
          onClick={() => setSelectedId(null)}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
        >
          <div
            className={`relative w-[480px] h-[480px] rounded-xl shadow-2xl transition-colors duration-200 border ${
              isLightMode
                ? 'bg-white border-neutral-300 shadow-neutral-400/20'
                : 'bg-neutral-900 border-neutral-800 shadow-black/80'
            } ${showGrid ? (isLightMode ? 'bg-grid-pattern-light' : 'bg-grid-pattern') : ''}`}
          >
            {/* SVG Root */}
            <svg
              ref={svgRef}
              viewBox="0 0 480 480"
              className="w-full h-full cursor-crosshair overflow-visible"
            >
              {/* Render canvas elements sorted by zIndex */}
              {[...elements]
                .sort((a, b) => a.zIndex - b.zIndex)
                .map((el) => {
                  const isSelected = el.id === selectedId;

                  return (
                    <g
                      key={el.id}
                      transform={`translate(${el.x}, ${el.y}) rotate(${el.rotation} ${el.width / 2} ${el.height / 2})`}
                      opacity={el.opacity}
                      onMouseDown={(e) => handleMouseDown(e, el.id)}
                      className="cursor-move"
                    >
                      {/* Element Body */}
                      {el.type === 'shape' && el.shapeType && (
                        renderShapeSvg(
                          el.shapeType,
                          el.width,
                          el.height,
                          el.fill,
                          el.stroke,
                          el.strokeWidth
                        )
                      )}

                      {el.type === 'icon' && el.pathData && (
                        <svg
                          viewBox="0 0 100 100"
                          width={el.width}
                          height={el.height}
                          fill={el.fill}
                          stroke={el.stroke}
                          strokeWidth={el.strokeWidth}
                        >
                          <path d={el.pathData} />
                        </svg>
                      )}

                      {el.type === 'text' && (
                        <text
                          x={el.width / 2}
                          y={el.height * 0.75}
                          textAnchor="middle"
                          fill={el.fill}
                          stroke={el.stroke}
                          strokeWidth={el.strokeWidth}
                          fontFamily={el.fontFamily || 'Syne'}
                          fontSize={el.fontSize || 24}
                          fontWeight={el.fontWeight || 700}
                          letterSpacing={el.letterSpacing || 2}
                          style={{
                            textTransform: el.textTransform || 'none'
                          }}
                        >
                          {el.text}
                        </text>
                      )}

                      {/* Selection Box & Transform Bounding Handles */}
                      {isSelected && (
                        <g pointerEvents="none">
                          <rect
                            x={-2}
                            y={-2}
                            width={el.width + 4}
                            height={el.height + 4}
                            fill="none"
                            stroke="#F59E0B"
                            strokeWidth="1.5"
                            strokeDasharray="4 4"
                          />
                          <circle cx={-2} cy={-2} r={4} fill="#F59E0B" />
                          <circle cx={el.width + 2} cy={-2} r={4} fill="#F59E0B" />
                          <circle cx={-2} cy={el.height + 2} r={4} fill="#F59E0B" />
                          <circle cx={el.width + 2} cy={el.height + 2} r={4} fill="#F59E0B" />
                        </g>
                      )}
                    </g>
                  );
                })}
            </svg>

            {/* Empty canvas guide */}
            {elements.length === 0 && (
              <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-6 pointer-events-none">
                <Sparkles className="w-10 h-10 text-amber-400 mb-2 opacity-60" />
                <h3 className="font-display text-lg font-bold text-neutral-300">
                  Station 1 Is Ready
                </h3>
                <p className="text-xs text-neutral-500 max-w-xs mt-1">
                  Choose shapes, typography, or mandatory basket motifs on the left to forge your mark!
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Selected Element Floating Inspector */}
        {selectedElement && (
          <div className="bg-neutral-900 border-t border-neutral-800 px-6 py-2.5 flex flex-wrap items-center justify-between gap-4 text-xs select-none">
            {/* Quick transforms */}
            <div className="flex items-center gap-2">
              <span className="font-mono text-neutral-400 uppercase text-[10px]">
                {selectedElement.type.toUpperCase()}:
              </span>

              {/* Text value if text */}
              {selectedElement.type === 'text' && (
                <input
                  type="text"
                  value={selectedElement.text || ''}
                  onChange={(e) => updateSelected({ text: e.target.value })}
                  className="px-2 py-1 bg-neutral-950 border border-neutral-700 rounded text-neutral-100 font-sans w-32 focus:outline-none focus:border-amber-400"
                />
              )}

              {/* Font Family selector if text */}
              {selectedElement.type === 'text' && (
                <select
                  value={selectedElement.fontFamily || 'Syne'}
                  onChange={(e) => updateSelected({ fontFamily: e.target.value })}
                  className="px-2 py-1 bg-neutral-950 border border-neutral-700 rounded text-neutral-200 focus:outline-none focus:border-amber-400"
                >
                  <option value="Syne">Syne (Display)</option>
                  <option value="Plus Jakarta Sans">Jakarta Sans (Clean)</option>
                  <option value="JetBrains Mono">JetBrains (Mono)</option>
                  <option value="serif">Classic Serif</option>
                  <option value="sans-serif">System Sans</option>
                </select>
              )}

              {/* Size Slider */}
              <div className="flex items-center gap-1.5 ml-2">
                <span className="text-neutral-400">Scale:</span>
                <input
                  type="range"
                  min="20"
                  max="320"
                  value={selectedElement.width}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    updateSelected({
                      width: val,
                      height: selectedElement.type === 'text' ? selectedElement.height : val,
                      fontSize: selectedElement.type === 'text' ? Math.round(val / 6) : undefined
                    });
                  }}
                  className="w-20 accent-amber-400"
                />
                <span className="font-mono text-[10px] text-neutral-400 w-8 tabular-nums">
                  {selectedElement.width}px
                </span>
              </div>

              {/* Rotation Dial */}
              <div className="flex items-center gap-1.5 ml-2">
                <span className="text-neutral-400">Rotate:</span>
                <input
                  type="range"
                  min="0"
                  max="360"
                  value={selectedElement.rotation}
                  onChange={(e) => updateSelected({ rotation: Number(e.target.value) })}
                  className="w-20 accent-amber-400"
                />
                <span className="font-mono text-[10px] text-neutral-400 w-8 tabular-nums">
                  {selectedElement.rotation}°
                </span>
              </div>
            </div>

            {/* Color & Layer Actions */}
            <div className="flex items-center gap-3">
              {/* Color pickers */}
              <div className="flex items-center gap-1.5">
                <span className="text-neutral-400">Fill:</span>
                <input
                  type="color"
                  value={selectedElement.fill.startsWith('#') ? selectedElement.fill : '#ffffff'}
                  onChange={(e) => updateSelected({ fill: e.target.value })}
                  className="w-6 h-6 rounded cursor-pointer border border-neutral-700 bg-transparent p-0"
                />
              </div>

              <div className="flex items-center gap-1.5">
                <span className="text-neutral-400">Stroke:</span>
                <input
                  type="color"
                  value={selectedElement.stroke.startsWith('#') ? selectedElement.stroke : '#000000'}
                  onChange={(e) => updateSelected({ stroke: e.target.value, strokeWidth: selectedElement.strokeWidth || 3 })}
                  className="w-6 h-6 rounded cursor-pointer border border-neutral-700 bg-transparent p-0"
                />
                <button
                  onClick={() => updateSelected({ stroke: 'transparent', strokeWidth: 0 })}
                  className="text-[10px] text-neutral-400 hover:text-white"
                  title="Remove stroke"
                >
                  None
                </button>
              </div>

              {/* Layering & Actions */}
              <div className="flex items-center gap-1 border-l border-neutral-800 pl-3">
                <button
                  onClick={bringForward}
                  title="Bring Forward"
                  className="p-1 rounded hover:bg-neutral-800 text-neutral-300"
                >
                  <ArrowUp className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={sendBackward}
                  title="Send Backward"
                  className="p-1 rounded hover:bg-neutral-800 text-neutral-300"
                >
                  <ArrowDown className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={duplicateSelected}
                  title="Duplicate Element"
                  className="p-1 rounded hover:bg-neutral-800 text-neutral-300"
                >
                  <Copy className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={deleteSelected}
                  title="Delete Element (Backspace)"
                  className="p-1 rounded hover:bg-neutral-800 text-red-400 hover:text-red-300"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Feedback toast for copy */}
        {copyCodeSuccess && (
          <div className="absolute top-14 right-6 px-3 py-1.5 bg-emerald-500 text-neutral-950 font-semibold text-xs rounded-md shadow-lg transition-opacity animate-in fade-in">
            Vector SVG code copied to clipboard!
          </div>
        )}
      </div>
    </div>
  );
};
