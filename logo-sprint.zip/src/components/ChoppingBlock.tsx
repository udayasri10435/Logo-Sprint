import React, { useState } from 'react';
import {
  Skull,
  Award,
  Sparkles,
  ChevronRight,
  ShieldAlert,
  Flame,
  CheckCircle2,
  XCircle,
  HelpCircle
} from 'lucide-react';
import { Designer, Judge, MysteryBrief } from '../types';
import { JUDGES } from '../data/briefs';
import { renderShapeSvg } from '../utils/vectorPaths';
import { sound } from '../utils/audio';

interface ChoppingBlockProps {
  designers: Designer[];
  brief: MysteryBrief;
  onAdvanceToFinale: (winner: Designer) => void;
}

export const ChoppingBlock: React.FC<ChoppingBlockProps> = ({
  designers,
  brief,
  onAdvanceToFinale
}) => {
  const [isChoppedRevealed, setIsChoppedRevealed] = useState<boolean>(false);
  const [selectedDesignerId, setSelectedDesignerId] = useState<string>(designers[0]?.id || '');

  // Calculate scores for each designer based on elements & twist compliance
  const getEvaluatedDesigners = () => {
    return designers.map((d) => {
      // Dynamic scores
      const baseCraft = d.isUser
        ? Math.min(96, Math.max(70, 75 + d.elements.length * 3))
        : d.critique?.judgeScores.craft || 88;
      const baseCompliance = d.twistIntegrated ? 92 : 72;
      const baseCreativity = d.isUser ? 90 : d.critique?.judgeScores.creativity || 85;
      const total = Math.round((baseCraft + baseCompliance + baseCreativity) / 3);

      return {
        ...d,
        calculatedScore: total,
        complianceScore: baseCompliance,
        craftScore: baseCraft,
        creativityScore: baseCreativity
      };
    });
  };

  const evaluated = getEvaluatedDesigners();

  // Find the lowest scoring rival to be the Chopped candidate
  const sorted = [...evaluated].sort((a, b) => b.calculatedScore - a.calculatedScore);
  const choppedCandidate = sorted[sorted.length - 1];
  const winnerCandidate = sorted[0];

  const handleRevealChop = () => {
    sound.choppedImpact();
    setIsChoppedRevealed(true);
  };

  const activeDesigner = evaluated.find((d) => d.id === selectedDesignerId) || evaluated[0];

  return (
    <div className="flex-1 overflow-y-auto p-6 bg-neutral-950">
      <div className="max-w-6xl mx-auto space-y-8">
        {/* Chopping Ceremony Header */}
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-red-950/60 border border-red-800/80 rounded-full text-red-400 text-xs font-mono font-bold uppercase tracking-wider">
            <Skull className="w-3.5 h-3.5" />
            <span>The Chopping Ceremony</span>
          </div>
          <h2 className="font-display text-3xl md:text-4xl font-extrabold text-white tracking-tight">
            Whose Logo Is on the Chopping Block?
          </h2>
          <p className="text-sm text-neutral-400">
            The judges have scrutinized every vector contour, the mystery basket adherence, and the 30-minute surprise twist.
          </p>
        </div>

        {/* The 3 Judges Table */}
        <div className="bg-neutral-900/80 border border-neutral-800 rounded-2xl p-6">
          <div className="text-xs uppercase font-mono tracking-wider text-amber-400 mb-4">
            The Judges' Table
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {JUDGES.map((judge) => (
              <div
                key={judge.id}
                className="bg-neutral-950 rounded-xl border border-neutral-800 p-4 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-amber-500 to-amber-200 text-neutral-950 font-display font-bold flex items-center justify-center text-sm shadow-md">
                      {judge.name.charAt(0)}
                    </div>
                    <div>
                      <h4 className="font-display font-bold text-white text-sm">
                        {judge.name}
                      </h4>
                      <div className="text-[11px] text-neutral-400">
                        {judge.role}
                      </div>
                    </div>
                  </div>

                  <p className="text-xs text-neutral-300 italic mb-2">
                    "{judge.quote}"
                  </p>
                </div>

                <div className="text-[10px] text-neutral-500 border-t border-neutral-800 pt-2 font-mono">
                  {judge.personality}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Contestants Deliberation Cards */}
        <div>
          <div className="text-xs uppercase font-mono tracking-wider text-neutral-400 mb-3">
            Click Contestant to Inspect Scorecard
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {evaluated.map((designer) => {
              const isSelected = selectedDesignerId === designer.id;
              const isChopped = isChoppedRevealed && designer.id === choppedCandidate.id;

              return (
                <button
                  key={designer.id}
                  onClick={() => {
                    sound.pop();
                    setSelectedDesignerId(designer.id);
                  }}
                  className={`p-4 rounded-xl border text-left transition-all relative flex flex-col justify-between ${
                    isChopped
                      ? 'bg-red-950/40 border-red-600 ring-2 ring-red-600/50'
                      : isSelected
                      ? 'bg-amber-400/10 border-amber-400 ring-1 ring-amber-400'
                      : 'bg-neutral-900 border-neutral-800 hover:border-neutral-700'
                  }`}
                >
                  {isChopped && (
                    <div className="absolute -top-3 right-3 px-2 py-0.5 bg-red-600 text-white font-mono font-bold text-[10px] rounded uppercase shadow-lg">
                      CHOPPED!
                    </div>
                  )}

                  <div>
                    <div className="text-[10px] font-mono text-amber-400 font-bold uppercase">
                      STATION {designer.stationNumber} {designer.isUser ? '(YOU)' : ''}
                    </div>
                    <div className="font-display font-bold text-white text-base mt-0.5 truncate">
                      {designer.name}
                    </div>
                  </div>

                  {/* Logo mini */}
                  <div className="w-full aspect-square bg-neutral-950 rounded-lg border border-neutral-800 my-3 p-2 flex items-center justify-center">
                    <svg viewBox="0 0 480 480" className="w-full h-full">
                      {[...designer.elements]
                        .sort((a, b) => a.zIndex - b.zIndex)
                        .map((el) => (
                          <g
                            key={el.id}
                            transform={`translate(${el.x}, ${el.y}) rotate(${el.rotation} ${el.width / 2} ${el.height / 2})`}
                            opacity={el.opacity}
                          >
                            {el.type === 'shape' && el.shapeType && (
                              renderShapeSvg(
                                el.shapeType,
                                el.width,
                                el.height,
                                el.fill,
                                el.stroke,
                                el.strokeWidth
                              )
                            )}
                            {el.type === 'text' && (
                              <text
                                x={el.width / 2}
                                y={el.height * 0.75}
                                textAnchor="middle"
                                fill={el.fill}
                                stroke={el.stroke}
                                strokeWidth={el.strokeWidth}
                                fontFamily={el.fontFamily || 'Syne'}
                                fontSize={el.fontSize || 24}
                                fontWeight={el.fontWeight || 700}
                                letterSpacing={el.letterSpacing || 2}
                                style={{ textTransform: el.textTransform || 'none' }}
                              >
                                {el.text}
                              </text>
                            )}
                          </g>
                        ))}
                    </svg>
                  </div>

                  <div className="flex items-center justify-between text-xs pt-1 border-t border-neutral-800">
                    <span className="text-neutral-400">Score:</span>
                    <span className="font-mono font-bold text-amber-400">
                      {designer.calculatedScore}/100
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Selected Contestant Deep Dive Critique */}
        <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-neutral-800 pb-4 mb-5">
            <div>
              <div className="text-[11px] font-mono uppercase text-amber-400">
                OFFICIAL JUDGES CRITIQUE · STATION {activeDesigner.stationNumber}
              </div>
              <h3 className="font-display text-2xl font-bold text-white mt-0.5">
                {activeDesigner.name}
              </h3>
              <p className="text-xs text-neutral-400 mt-0.5">
                {activeDesigner.styleSchool}
              </p>
            </div>

            <div className="flex items-center gap-6">
              <div className="text-center">
                <div className="text-[10px] font-mono uppercase text-neutral-400">
                  Compliance
                </div>
                <div className="text-lg font-mono font-bold text-emerald-400">
                  {activeDesigner.complianceScore}%
                </div>
              </div>
              <div className="text-center">
                <div className="text-[10px] font-mono uppercase text-neutral-400">
                  Craft
                </div>
                <div className="text-lg font-mono font-bold text-blue-400">
                  {activeDesigner.craftScore}%
                </div>
              </div>
              <div className="text-center">
                <div className="text-[10px] font-mono uppercase text-neutral-400">
                  Creativity
                </div>
                <div className="text-lg font-mono font-bold text-purple-400">
                  {activeDesigner.creativityScore}%
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="text-xs uppercase font-mono tracking-wider text-neutral-400 mb-2">
                Designer Concept Rationale
              </h4>
              <p className="text-xs text-neutral-300 leading-relaxed bg-neutral-950 p-4 rounded-xl border border-neutral-800">
                "{activeDesigner.rationale || 'Built around balanced geometry, contrasting weights, and tight optical alignment.'}"
              </p>
            </div>

            <div>
              <h4 className="text-xs uppercase font-mono tracking-wider text-neutral-400 mb-2">
                Judges Consensus
              </h4>
              <div className="bg-neutral-950 p-4 rounded-xl border border-neutral-800 space-y-2 text-xs">
                <p className="text-neutral-200 font-medium">
                  {activeDesigner.critique?.verdict ||
                    'Strong presence. The interplay of the mystery basket elements creates a memorable brand silhouette.'}
                </p>
                <div className="text-neutral-400 flex items-center gap-1.5 pt-1">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Basket elements resolved into a unified hierarchy.</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* The Chopping Reveal Bar */}
        <div className="bg-gradient-to-r from-red-950/50 via-neutral-900 to-red-950/50 border border-red-900/60 rounded-2xl p-6 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-red-600/20 border border-red-500/40 flex items-center justify-center text-red-400 shrink-0">
              <Skull className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-display text-xl font-bold text-white">
                {isChoppedRevealed
                  ? `Station ${choppedCandidate.stationNumber} (${choppedCandidate.name}) has been Chopped!`
                  : 'Ready for the Chopping Block Reveal?'}
              </h3>
              <p className="text-xs text-neutral-400 mt-0.5">
                {isChoppedRevealed
                  ? 'Their design failed to sufficiently integrate the mandatory ingredients under intense pressure.'
                  : 'Lift the cloche to reveal which designer leaves the competition.'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {!isChoppedRevealed ? (
              <button
                onClick={handleRevealChop}
                className="px-6 py-3 bg-red-600 hover:bg-red-500 text-white text-xs font-bold rounded-xl transition-all shadow-lg shadow-red-600/30 flex items-center gap-2 uppercase tracking-wider"
              >
                <Skull className="w-4 h-4" />
                <span>Lift Cloche (Execute Chop)</span>
              </button>
            ) : (
              <button
                onClick={() => {
                  sound.fanfare();
                  onAdvanceToFinale(winnerCandidate);
                }}
                className="px-6 py-3 bg-amber-400 hover:bg-amber-300 text-neutral-950 text-xs font-bold rounded-xl transition-all shadow-lg shadow-amber-500/30 flex items-center gap-2 uppercase tracking-wider"
              >
                <Award className="w-4 h-4" />
                <span>Crown Champion Finale</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
