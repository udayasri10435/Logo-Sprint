import React, { useEffect, useRef, useState } from 'react';
import confetti from 'canvas-confetti';
import {
  Trophy,
  Download,
  Copy,
  Check,
  Sparkles,
  Smartphone,
  Coffee,
  ShoppingBag,
  CreditCard,
  Building2,
  RotateCcw
} from 'lucide-react';
import { CanvasElement, Designer, MysteryBrief } from '../types';
import { renderShapeSvg } from '../utils/vectorPaths';
import { sound } from '../utils/audio';

interface MockupPreviewProps {
  designer: Designer;
  brief: MysteryBrief;
  onRestartSprint: () => void;
}

export const MockupPreview: React.FC<MockupPreviewProps> = ({
  designer,
  brief,
  onRestartSprint
}) => {
  const [copiedCode, setCopiedCode] = useState(false);
  const [activeMockupTab, setActiveMockupTab] = useState<'all' | 'card' | 'store' | 'tote' | 'mobile'>('all');
  const svgContainerRef = useRef<HTMLDivElement>(null);

  // Trigger confetti celebration on mount
  useEffect(() => {
    sound.fanfare();
    confetti({
      particleCount: 100,
      spread: 70,
      origin: { y: 0.6 }
    });
  }, []);

  const copySvg = () => {
    sound.pop();
    if (svgContainerRef.current) {
      const svg = svgContainerRef.current.querySelector('svg');
      if (svg) {
        const serializer = new XMLSerializer();
        const str = serializer.serializeToString(svg);
        navigator.clipboard.writeText(str);
        setCopiedCode(true);
        setTimeout(() => setCopiedCode(false), 2000);
      }
    }
  };

  // Render the logo SVG inside mockups
  const renderLogo = (scale = 1, forceWhite = false) => {
    return (
      <svg viewBox="0 0 480 480" className="w-full h-full max-w-full max-h-full">
        {[...designer.elements]
          .sort((a, b) => a.zIndex - b.zIndex)
          .map((el) => (
            <g
              key={el.id}
              transform={`translate(${el.x}, ${el.y}) rotate(${el.rotation} ${el.width / 2} ${el.height / 2})`}
              opacity={el.opacity}
            >
              {el.type === 'shape' && el.shapeType && (
                renderShapeSvg(
                  el.shapeType,
                  el.width,
                  el.height,
                  forceWhite ? '#ffffff' : el.fill,
                  forceWhite ? 'transparent' : el.stroke,
                  el.strokeWidth
                )
              )}
              {el.type === 'text' && (
                <text
                  x={el.width / 2}
                  y={el.height * 0.75}
                  textAnchor="middle"
                  fill={forceWhite ? '#ffffff' : el.fill}
                  stroke={forceWhite ? 'transparent' : el.stroke}
                  strokeWidth={el.strokeWidth}
                  fontFamily={el.fontFamily || 'Syne'}
                  fontSize={el.fontSize || 24}
                  fontWeight={el.fontWeight || 700}
                  letterSpacing={el.letterSpacing || 2}
                  style={{ textTransform: el.textTransform || 'none' }}
                >
                  {el.text}
                </text>
              )}
            </g>
          ))}
      </svg>
    );
  };

  return (
    <div className="flex-1 overflow-y-auto p-6 bg-neutral-950">
      <div className="max-w-6xl mx-auto space-y-8">
        {/* Victory Podium Banner */}
        <div className="relative rounded-2xl bg-gradient-to-r from-amber-950/60 via-neutral-900 to-amber-950/60 border border-amber-500/40 p-8 text-center overflow-hidden shadow-2xl">
          <div className="absolute inset-0 bg-grid-pattern opacity-10 pointer-events-none" />

          <div className="relative z-10 max-w-2xl mx-auto space-y-3">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-amber-400 text-neutral-950 font-mono text-xs font-bold uppercase rounded-md tracking-wider">
              <Trophy className="w-3.5 h-3.5 fill-current" />
              <span>LOGO SPRINT CHAMPION</span>
            </div>

            <h1 className="font-display text-4xl md:text-5xl font-black text-white tracking-tight">
              {designer.name} Takes the Caliper!
            </h1>

            <p className="text-sm text-neutral-300">
              Survived the 60-minute countdown, the diabolical mystery basket constraints, and the surprise mid-round twist for <strong className="text-amber-400">{brief.brandName}</strong>.
            </p>

            <div className="pt-3 flex flex-wrap items-center justify-center gap-3">
              <button
                onClick={copySvg}
                className="px-4 py-2 bg-neutral-800 hover:bg-neutral-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors border border-neutral-700"
              >
                {copiedCode ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4 text-amber-400" />}
                <span>{copiedCode ? 'Copied Vector SVG!' : 'Copy Vector SVG'}</span>
              </button>

              <button
                onClick={() => {
                  sound.pop();
                  onRestartSprint();
                }}
                className="px-4 py-2 bg-amber-400 hover:bg-amber-300 text-neutral-950 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors shadow-lg shadow-amber-500/20"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Play Another Sprint Round</span>
              </button>
            </div>
          </div>
        </div>

        {/* Real-World Brand Application Mockups */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-xs uppercase font-mono tracking-wider text-amber-400">
                REAL-WORLD DEPLOYMENT
              </div>
              <h2 className="font-display text-2xl font-bold text-white tracking-tight">
                Brand Identity Mockups
              </h2>
            </div>
            <span className="text-xs text-neutral-400">
              Tested across print, digital, and architectural mediums
            </span>
          </div>

          {/* Hidden reference SVG container for copying */}
          <div ref={svgContainerRef} className="hidden">
            {renderLogo()}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Mockup 1: Luxury Matte Business Card */}
            <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-5 flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-2 text-xs font-mono text-neutral-400 mb-3">
                  <CreditCard className="w-4 h-4 text-amber-400" />
                  <span>400gsm Black Cotton Card</span>
                </div>

                <div className="w-full aspect-[16/10] bg-neutral-950 rounded-lg border border-neutral-800 shadow-2xl p-6 flex flex-col justify-between relative overflow-hidden group">
                  <div className="w-24 h-24">
                    {renderLogo()}
                  </div>

                  <div className="space-y-1 text-left">
                    <div className="text-[11px] font-mono text-neutral-400 tracking-wider">
                      FOUNDER & PRINCIPAL
                    </div>
                    <div className="text-[10px] text-neutral-500 font-mono">
                      london · new york · tokyo
                    </div>
                  </div>
                </div>
              </div>

              <div className="text-[11px] text-neutral-400 mt-3">
                Spot UV gloss over tactile obsidian paper.
              </div>
            </div>

            {/* Mockup 2: Storefront Glass Signage */}
            <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-5 flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-2 text-xs font-mono text-neutral-400 mb-3">
                  <Building2 className="w-4 h-4 text-blue-400" />
                  <span>Architectural Glass Facade</span>
                </div>

                <div className="w-full aspect-[16/10] bg-gradient-to-tr from-slate-900 via-neutral-900 to-slate-800 rounded-lg border border-neutral-700 shadow-2xl p-8 flex items-center justify-center relative overflow-hidden">
                  <div className="w-44 h-44 drop-shadow-[0_15px_15px_rgba(0,0,0,0.8)]">
                    {renderLogo()}
                  </div>
                </div>
              </div>

              <div className="text-[11px] text-neutral-400 mt-3">
                Precision laser-cut bronze with backlit illumination.
              </div>
            </div>

            {/* Mockup 3: Heavyweight Organic Tote */}
            <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-5 flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-2 text-xs font-mono text-neutral-400 mb-3">
                  <ShoppingBag className="w-4 h-4 text-emerald-400" />
                  <span>Natural Canvas Tote Bag</span>
                </div>

                <div className="w-full aspect-[16/10] bg-amber-50 rounded-lg shadow-inner p-6 flex items-center justify-center relative overflow-hidden">
                  <div className="w-36 h-36 opacity-90 contrast-125">
                    {renderLogo(1, false)}
                  </div>
                </div>
              </div>

              <div className="text-[11px] text-neutral-400 mt-3">
                Silk screen print on 16oz unbleached canvas.
              </div>
            </div>

            {/* Mockup 4: Mobile App Icon */}
            <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-5 flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-2 text-xs font-mono text-neutral-400 mb-3">
                  <Smartphone className="w-4 h-4 text-purple-400" />
                  <span>iOS 18 Squircle Icon</span>
                </div>

                <div className="w-full aspect-[16/10] bg-neutral-950 rounded-lg border border-neutral-800 shadow-2xl p-6 flex items-center justify-center">
                  <div className="w-24 h-24 bg-neutral-900 rounded-[22px] border border-neutral-700 shadow-2xl p-3 flex items-center justify-center overflow-hidden">
                    {renderLogo()}
                  </div>
                </div>
              </div>

              <div className="text-[11px] text-neutral-400 mt-3">
                Micro-scale legibility and home screen presence.
              </div>
            </div>

            {/* Mockup 5: Ceramic Espresso Cup */}
            <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-5 flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-2 text-xs font-mono text-neutral-400 mb-3">
                  <Coffee className="w-4 h-4 text-amber-500" />
                  <span>Matte Ceramic Stoneware</span>
                </div>

                <div className="w-full aspect-[16/10] bg-stone-900 rounded-lg border border-stone-800 shadow-2xl p-6 flex items-center justify-center">
                  <div className="w-28 h-28 rounded-full bg-stone-800 border border-stone-700 shadow-inner flex items-center justify-center p-4">
                    <div className="w-16 h-16">
                      {renderLogo()}
                    </div>
                  </div>
                </div>
              </div>

              <div className="text-[11px] text-neutral-400 mt-3">
                Engraved deboss on artisan ceramic tableware.
              </div>
            </div>

            {/* Mockup 6: Favicon & Micro-Scale Test */}
            <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-5 flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-2 text-xs font-mono text-neutral-400 mb-3">
                  <Sparkles className="w-4 h-4 text-cyan-400" />
                  <span>Favicon & Micro-Scale (16px / 32px)</span>
                </div>

                <div className="w-full aspect-[16/10] bg-neutral-950 rounded-lg border border-neutral-800 shadow-2xl p-6 flex flex-col items-center justify-center gap-4">
                  <div className="flex items-center gap-6">
                    <div className="flex flex-col items-center gap-1">
                      <div className="w-8 h-8 bg-neutral-900 rounded border border-neutral-700 flex items-center justify-center p-1">
                        {renderLogo()}
                      </div>
                      <span className="text-[9px] font-mono text-neutral-500">32px</span>
                    </div>

                    <div className="flex flex-col items-center gap-1">
                      <div className="w-4 h-4 bg-neutral-900 rounded border border-neutral-700 flex items-center justify-center p-0.5">
                        {renderLogo()}
                      </div>
                      <span className="text-[9px] font-mono text-neutral-500">16px</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="text-[11px] text-neutral-400 mt-3">
                Marcus Sterling's test: Does the mark hold integrity at tab icon size?
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
