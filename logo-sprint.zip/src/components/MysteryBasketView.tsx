import React, { useState } from 'react';
import {
  Sparkles,
  Flame,
  AlertTriangle,
  Feather,
  Type,
  Shuffle,
  ChevronRight,
  ShieldCheck,
  Check
} from 'lucide-react';
import { MysteryBrief } from '../types';
import { MYSTERY_BRIEFS } from '../data/briefs';
import { sound } from '../utils/audio';

interface MysteryBasketViewProps {
  brief: MysteryBrief;
  onSelectBrief: (brief: MysteryBrief) => void;
  twistTriggered: boolean;
  onStartSprint: () => void;
}

export const MysteryBasketView: React.FC<MysteryBasketViewProps> = ({
  brief,
  onSelectBrief,
  twistTriggered,
  onStartSprint
}) => {
  const [clocheOpened, setClocheOpened] = useState<boolean>(true);
  const [copiedHex, setCopiedHex] = useState<string | null>(null);

  const copyHex = (hex: string) => {
    sound.pop();
    navigator.clipboard.writeText(hex);
    setCopiedHex(hex);
    setTimeout(() => setCopiedHex(null), 1500);
  };

  const handleRandomize = () => {
    sound.clocheBell();
    const otherBriefs = MYSTERY_BRIEFS.filter((b) => b.id !== brief.id);
    const random = otherBriefs[Math.floor(Math.random() * otherBriefs.length)] || MYSTERY_BRIEFS[0];
    onSelectBrief(random);
  };

  return (
    <div className="flex-1 overflow-y-auto p-6 bg-neutral-950">
      <div className="max-w-5xl mx-auto space-y-8">
        {/* Chopped Hero Header */}
        <div className="relative bg-gradient-to-b from-neutral-900 via-neutral-900 to-neutral-950 rounded-2xl border border-neutral-800 p-8 overflow-hidden shadow-2xl">
          {/* Subtle gold flare background glow */}
          <div className="absolute -top-24 -right-24 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

          <div className="relative z-10">
            <div className="flex flex-wrap items-center justify-between gap-4 mb-4">
              <div className="flex items-center gap-2">
                <span className="px-3 py-1 bg-amber-400 text-neutral-950 text-xs font-mono font-bold uppercase rounded-md tracking-wider">
                  OFFICIAL MYSTERY BASKET
                </span>
                <span className="text-xs text-neutral-400 font-mono">
                  {brief.industry}
                </span>
              </div>

              <div className="flex items-center gap-3">
                <button
                  onClick={handleRandomize}
                  className="px-3 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-semibold rounded-lg border border-neutral-700 flex items-center gap-1.5 transition-colors"
                >
                  <Shuffle className="w-3.5 h-3.5 text-amber-400" />
                  <span>Randomize Basket</span>
                </button>

                <button
                  onClick={() => {
                    sound.pop();
                    onStartSprint();
                  }}
                  className="px-4 py-1.5 bg-amber-400 hover:bg-amber-300 text-neutral-950 text-xs font-bold rounded-lg transition-colors flex items-center gap-1.5 shadow-md shadow-amber-500/20"
                >
                  <span>Enter Arena</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            <h1 className="font-display text-4xl md:text-5xl font-black text-white tracking-tight uppercase">
              {brief.brandName}
            </h1>
            <p className="text-lg text-amber-400/90 font-medium italic mt-1 font-serif">
              "{brief.tagline}"
            </p>

            <p className="text-sm text-neutral-300 mt-4 max-w-3xl leading-relaxed">
              {brief.story}
            </p>

            <div className="mt-4 pt-4 border-t border-neutral-800/80 flex flex-wrap gap-4 text-xs text-neutral-400">
              <div>
                <strong className="text-neutral-200">Target Demographic:</strong>{' '}
                {brief.targetAudience}
              </div>
            </div>
          </div>
        </div>

        {/* The 4 Mandatory Basket Ingredients */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <div>
              <div className="text-xs uppercase font-mono tracking-wider text-amber-400">
                REQUIRED INGREDIENTS
              </div>
              <h2 className="font-display text-2xl font-bold text-white tracking-tight">
                Mandatory Basket Constraints
              </h2>
            </div>
            <span className="text-xs text-neutral-400">
              Judges verify all 4 at the Chopping Block
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Ingredient 1: Symbol & Motif */}
            <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-5 hover:border-neutral-700 transition-colors">
              <div className="flex items-start gap-3.5">
                <div className="p-2.5 bg-amber-400/10 rounded-lg border border-amber-400/20 text-amber-400 shrink-0">
                  <Sparkles className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-[11px] font-mono uppercase tracking-wider text-amber-400 font-semibold">
                    Ingredient 01 · Visual Motif
                  </div>
                  <h3 className="font-display text-lg font-bold text-white mt-0.5">
                    {brief.basket.symbolMotif.title}
                  </h3>
                  <p className="text-xs text-neutral-400 mt-1 leading-relaxed">
                    {brief.basket.symbolMotif.detail}
                  </p>
                </div>
              </div>
            </div>

            {/* Ingredient 2: Paradox Constraint */}
            <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-5 hover:border-neutral-700 transition-colors">
              <div className="flex items-start gap-3.5">
                <div className="p-2.5 bg-emerald-400/10 rounded-lg border border-emerald-400/20 text-emerald-400 shrink-0">
                  <Feather className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-[11px] font-mono uppercase tracking-wider text-emerald-400 font-semibold">
                    Ingredient 02 · Paradox Tension
                  </div>
                  <h3 className="font-display text-lg font-bold text-white mt-0.5">
                    {brief.basket.paradoxConstraint.title}
                  </h3>
                  <p className="text-xs text-neutral-400 mt-1 leading-relaxed">
                    {brief.basket.paradoxConstraint.detail}
                  </p>
                </div>
              </div>
            </div>

            {/* Ingredient 3: Wordmark Rule */}
            <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-5 hover:border-neutral-700 transition-colors">
              <div className="flex items-start gap-3.5">
                <div className="p-2.5 bg-blue-400/10 rounded-lg border border-blue-400/20 text-blue-400 shrink-0">
                  <Type className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-[11px] font-mono uppercase tracking-wider text-blue-400 font-semibold">
                    Ingredient 03 · Typecraft Rule
                  </div>
                  <h3 className="font-display text-lg font-bold text-white mt-0.5">
                    {brief.basket.wordmarkRule.title}
                  </h3>
                  <p className="text-xs text-neutral-400 mt-1 leading-relaxed">
                    {brief.basket.wordmarkRule.detail}
                  </p>
                </div>
              </div>
            </div>

            {/* Ingredient 4: 4-Color Palette Swatches */}
            <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-5 hover:border-neutral-700 transition-colors">
              <div className="text-[11px] font-mono uppercase tracking-wider text-purple-400 font-semibold mb-1">
                Ingredient 04 · Mandatory Palette
              </div>
              <h3 className="font-display text-lg font-bold text-white mb-3">
                4-Hue Brand Spectrum
              </h3>

              <div className="grid grid-cols-4 gap-2">
                {brief.basket.colorPalette.map((col, idx) => (
                  <button
                    key={idx}
                    onClick={() => copyHex(col.hex)}
                    className="group text-left"
                    title={`Click to copy ${col.hex}`}
                  >
                    <div
                      className="w-full h-12 rounded-lg border border-neutral-700 transition-transform group-hover:scale-105 flex items-center justify-center relative"
                      style={{ backgroundColor: col.hex }}
                    >
                      {copiedHex === col.hex && (
                        <div className="absolute inset-0 bg-black/60 rounded-lg flex items-center justify-center">
                          <Check className="w-4 h-4 text-emerald-400" />
                        </div>
                      )}
                    </div>
                    <div className="mt-1.5">
                      <div className="text-[10px] font-semibold text-neutral-200 truncate">
                        {col.name}
                      </div>
                      <div className="text-[9px] font-mono text-neutral-400 uppercase">
                        {col.hex}
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* The Mid-Round Twist Alert */}
        <div
          className={`rounded-2xl border p-6 transition-all ${
            twistTriggered
              ? 'bg-amber-950/30 border-amber-500/50 ring-1 ring-amber-500/30'
              : 'bg-neutral-900/50 border-neutral-800'
          }`}
        >
          <div className="flex items-start gap-4">
            <div
              className={`p-3 rounded-xl border shrink-0 ${
                twistTriggered
                  ? 'bg-amber-500/20 border-amber-500/40 text-amber-400 animate-pulse'
                  : 'bg-neutral-800 border-neutral-700 text-neutral-400'
              }`}
            >
              <AlertTriangle className="w-6 h-6" />
            </div>

            <div className="flex-1">
              <div className="flex items-center justify-between gap-2">
                <span
                  className={`text-xs font-mono font-bold uppercase tracking-wider ${
                    twistTriggered ? 'text-amber-400' : 'text-neutral-400'
                  }`}
                >
                  {twistTriggered
                    ? '⚡ TWIST UNVEILED (HALFWAY STRIKE)'
                    : 'SURPRISE MID-ROUND TWIST (DROPS AT 30 MINUTES)'}
                </span>

                <span className="text-[11px] font-mono text-neutral-500">
                  Requirement
                </span>
              </div>

              <h3 className="font-display text-xl font-bold text-white mt-1">
                {brief.twist.title}
              </h3>

              <p className="text-xs text-neutral-300 mt-1 leading-relaxed">
                {brief.twist.description}
              </p>

              <div className="mt-3 p-3 bg-neutral-950 rounded-lg border border-neutral-800 text-xs flex items-center justify-between">
                <span className="text-neutral-400">
                  <strong className="text-amber-400">Mandatory Addition:</strong>{' '}
                  {brief.twist.requirement}
                </span>
                <span className="px-2 py-0.5 bg-amber-400/10 text-amber-300 font-mono font-semibold rounded border border-amber-400/20 text-[10px] whitespace-nowrap">
                  +{brief.twist.bonusIngredient}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Other Challenges Picker Carousel */}
        <div>
          <div className="text-xs uppercase font-mono tracking-wider text-neutral-400 mb-3">
            Switch Chopped Brief
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {MYSTERY_BRIEFS.map((b) => (
              <button
                key={b.id}
                onClick={() => {
                  sound.pop();
                  onSelectBrief(b);
                }}
                className={`p-3 rounded-xl border text-left transition-all ${
                  b.id === brief.id
                    ? 'bg-amber-400/10 border-amber-400 text-white shadow-md shadow-amber-500/10'
                    : 'bg-neutral-900 border-neutral-800 text-neutral-400 hover:text-white hover:border-neutral-700'
                }`}
              >
                <div className="text-xs font-display font-bold truncate">
                  {b.brandName}
                </div>
                <div className="text-[10px] text-neutral-400 mt-0.5 truncate">
                  {b.industry}
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
