import React from 'react';
import { X, Sparkles, Shuffle, Flame } from 'lucide-react';
import { MysteryBrief } from '../types';
import { MYSTERY_BRIEFS } from '../data/briefs';
import { sound } from '../utils/audio';

interface NewBriefModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectBrief: (brief: MysteryBrief) => void;
  activeBriefId: string;
}

export const NewBriefModal: React.FC<NewBriefModalProps> = ({
  isOpen,
  onClose,
  onSelectBrief,
  activeBriefId
}) => {
  if (!isOpen) return null;

  const handleRandomize = () => {
    sound.clocheBell();
    const otherBriefs = MYSTERY_BRIEFS.filter((b) => b.id !== activeBriefId);
    const chosen = otherBriefs[Math.floor(Math.random() * otherBriefs.length)] || MYSTERY_BRIEFS[0];
    onSelectBrief(chosen);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl bg-neutral-900 border border-neutral-800 rounded-2xl p-6 shadow-2xl space-y-5">
        <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
          <div className="flex items-center gap-2">
            <Flame className="w-5 h-5 text-amber-400 fill-current" />
            <h3 className="font-display text-xl font-bold text-white">
              Choose Mystery Basket Brief
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <p className="text-xs text-neutral-400">
          Each challenge contains 4 mandatory basket ingredients, strict brand paradoxes, and a mid-sprint surprise twist.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-h-96 overflow-y-auto pr-1">
          {MYSTERY_BRIEFS.map((b) => {
            const isSelected = b.id === activeBriefId;
            return (
              <button
                key={b.id}
                onClick={() => {
                  sound.clocheBell();
                  onSelectBrief(b);
                  onClose();
                }}
                className={`p-4 rounded-xl border text-left transition-all flex flex-col justify-between ${
                  isSelected
                    ? 'bg-amber-400/10 border-amber-400 text-white shadow-md shadow-amber-500/10'
                    : 'bg-neutral-950 border-neutral-800 text-neutral-300 hover:border-neutral-700 hover:bg-neutral-900'
                }`}
              >
                <div>
                  <div className="text-[10px] font-mono uppercase tracking-wider text-amber-400">
                    {b.industry}
                  </div>
                  <div className="font-display font-bold text-lg text-white mt-0.5">
                    {b.brandName}
                  </div>
                  <div className="text-xs text-neutral-400 italic mt-0.5">
                    "{b.tagline}"
                  </div>
                </div>

                <div className="mt-3 pt-2 border-t border-neutral-800/80 flex items-center justify-between text-[11px] text-neutral-400">
                  <span className="truncate max-w-[150px]">
                    Motif: {b.basket.symbolMotif.title}
                  </span>
                  <div className="flex items-center gap-1">
                    {b.basket.colorPalette.map((col, idx) => (
                      <span
                        key={idx}
                        className="w-2.5 h-2.5 rounded-full inline-block"
                        style={{ backgroundColor: col.hex }}
                      />
                    ))}
                  </div>
                </div>
              </button>
            );
          })}
        </div>

        <div className="pt-2 flex items-center justify-between border-t border-neutral-800">
          <button
            onClick={handleRandomize}
            className="px-4 py-2 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-semibold rounded-lg border border-neutral-700 flex items-center gap-2 transition-colors"
          >
            <Shuffle className="w-4 h-4 text-amber-400" />
            <span>Surprise Mystery Randomizer</span>
          </button>

          <button
            onClick={onClose}
            className="px-4 py-2 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs font-medium rounded-lg transition-colors"
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
};
