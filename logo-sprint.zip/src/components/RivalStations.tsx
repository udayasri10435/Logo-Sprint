import React, { useState } from 'react';
import { Eye, CheckCircle2, XCircle, Sparkles, User, ShieldAlert } from 'lucide-react';
import { Designer, MysteryBrief } from '../types';
import { renderShapeSvg } from '../utils/vectorPaths';
import { sound } from '../utils/audio';

interface RivalStationsProps {
  rivals: Designer[];
  brief: MysteryBrief;
  twistTriggered: boolean;
  onSelectStationForInspect?: (designer: Designer) => void;
}

export const RivalStations: React.FC<RivalStationsProps> = ({
  rivals,
  brief,
  twistTriggered
}) => {
  const [selectedStation, setSelectedStation] = useState<string | null>(null);

  return (
    <div className="flex-1 overflow-y-auto p-6 bg-neutral-950">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-neutral-800 pb-4">
          <div>
            <div className="text-xs uppercase font-mono tracking-wider text-amber-400 mb-1">
              COMPETITOR WORKBENCHES
            </div>
            <h2 className="font-display text-2xl md:text-3xl font-bold text-white tracking-tight">
              Live Rival Workstations
            </h2>
            <p className="text-sm text-neutral-400 mt-1">
              Observe how the other 3 designers are tackling the "{brief.brandName}" mystery basket in real-time.
            </p>
          </div>

          <div className="flex items-center gap-2 text-xs text-neutral-400 font-mono">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            <span>3 Stations Active · Round 1</span>
          </div>
        </div>

        {/* Rival Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {rivals.map((designer) => {
            const isSelected = selectedStation === designer.id;

            return (
              <div
                key={designer.id}
                onClick={() => {
                  sound.pop();
                  setSelectedStation(isSelected ? null : designer.id);
                }}
                className={`bg-neutral-900 rounded-xl border p-5 transition-all cursor-pointer flex flex-col justify-between ${
                  isSelected
                    ? 'border-amber-400 shadow-xl shadow-amber-500/10 ring-1 ring-amber-400'
                    : 'border-neutral-800 hover:border-neutral-700 hover:bg-neutral-900/80'
                }`}
              >
                <div>
                  {/* Station Number & Designer Header */}
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <div className="text-[11px] font-mono font-bold text-amber-400 uppercase tracking-widest">
                        STATION {designer.stationNumber}
                      </div>
                      <h3 className="font-display text-lg font-bold text-white tracking-tight mt-0.5">
                        {designer.name}
                      </h3>
                      <div className="text-xs text-neutral-400 mt-0.5">
                        {designer.title}
                      </div>
                    </div>

                    <span className="text-[11px] px-2 py-0.5 bg-neutral-950 border border-neutral-800 rounded font-medium text-neutral-300">
                      {designer.styleSchool.split(' ')[0]}
                    </span>
                  </div>

                  {/* Live SVG Vector Canvas Preview of Rival */}
                  <div className="w-full aspect-square bg-neutral-950 rounded-lg border border-neutral-800 p-4 mb-4 relative overflow-hidden flex items-center justify-center group">
                    <svg
                      viewBox="0 0 480 480"
                      className="w-full h-full transform transition-transform duration-300 group-hover:scale-105"
                    >
                      {[...designer.elements]
                        .sort((a, b) => a.zIndex - b.zIndex)
                        .map((el) => (
                          <g
                            key={el.id}
                            transform={`translate(${el.x}, ${el.y}) rotate(${el.rotation} ${el.width / 2} ${el.height / 2})`}
                            opacity={el.opacity}
                          >
                            {el.type === 'shape' && el.shapeType && (
                              renderShapeSvg(
                                el.shapeType,
                                el.width,
                                el.height,
                                el.fill,
                                el.stroke,
                                el.strokeWidth
                              )
                            )}

                            {el.type === 'text' && (
                              <text
                                x={el.width / 2}
                                y={el.height * 0.75}
                                textAnchor="middle"
                                fill={el.fill}
                                stroke={el.stroke}
                                strokeWidth={el.strokeWidth}
                                fontFamily={el.fontFamily || 'Syne'}
                                fontSize={el.fontSize || 22}
                                fontWeight={el.fontWeight || 700}
                                letterSpacing={el.letterSpacing || 2}
                                style={{ textTransform: el.textTransform || 'none' }}
                              >
                                {el.text}
                              </text>
                            )}
                          </g>
                        ))}
                    </svg>

                    {/* Live overlay tag */}
                    <div className="absolute top-2 right-2 flex items-center gap-1.5 px-2 py-0.5 bg-neutral-900/90 border border-neutral-700 rounded text-[10px] text-neutral-300 font-mono">
                      <span className="w-1.5 h-1.5 bg-amber-400 rounded-full animate-pulse" />
                      <span>LIVE WORK</span>
                    </div>
                  </div>

                  {/* Designer's Internal Monologue / Thought bubble */}
                  <div className="bg-neutral-950/70 p-3 rounded-lg border border-neutral-800/80 mb-3">
                    <div className="text-[10px] uppercase font-mono tracking-wider text-neutral-500 mb-1 flex items-center gap-1">
                      <span>Live Mic from Station</span>
                    </div>
                    <p className="text-xs text-neutral-300 italic">
                      "{designer.currentThought}"
                    </p>
                  </div>

                  {/* Twist Compliance Status */}
                  <div className="flex items-center justify-between text-xs py-1 text-neutral-400">
                    <span>Surprise Twist Handled:</span>
                    {twistTriggered ? (
                      designer.twistIntegrated ? (
                        <span className="text-emerald-400 flex items-center gap-1 text-[11px] font-semibold">
                          <CheckCircle2 className="w-3.5 h-3.5" /> Handled
                        </span>
                      ) : (
                        <span className="text-red-400 flex items-center gap-1 text-[11px] font-semibold">
                          <XCircle className="w-3.5 h-3.5" /> Missing
                        </span>
                      )
                    ) : (
                      <span className="text-neutral-500 text-[11px]">Pending Unveil</span>
                    )}
                  </div>
                </div>

                {/* Concept Rationale & Style School summary */}
                <div className="pt-3 border-t border-neutral-800 mt-2">
                  <div className="text-[11px] text-neutral-400 line-clamp-2">
                    {designer.rationale}
                  </div>
                  <div className="mt-3 flex items-center justify-between">
                    <span className="text-[11px] text-neutral-500">
                      Audience Sentiment: <strong className="text-amber-400">{designer.audienceVotes}%</strong>
                    </span>
                    <span className="text-xs text-amber-400 font-semibold hover:underline">
                      {isSelected ? 'Collapse' : 'Inspect Mark →'}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
