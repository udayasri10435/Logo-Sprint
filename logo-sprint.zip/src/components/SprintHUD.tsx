import React from 'react';
import { Play, Pause, FastForward, CheckCircle2, AlertTriangle, Sparkles } from 'lucide-react';
import { GamePhase, MysteryBrief } from '../types';
import { sound } from '../utils/audio';

interface SprintHUDProps {
  secondsLeft: number;
  totalSeconds: number;
  isRunning: boolean;
  onTogglePlay: () => void;
  onFastForward: (multiplier: number) => void;
  speedMultiplier: number;
  currentPhase: GamePhase;
  onAdvancePhase: (nextPhase: GamePhase) => void;
  brief: MysteryBrief;
  twistTriggered: boolean;
  onTriggerTwistEarly: () => void;
}

export const SprintHUD: React.FC<SprintHUDProps> = ({
  secondsLeft,
  totalSeconds,
  isRunning,
  onTogglePlay,
  onFastForward,
  speedMultiplier,
  currentPhase,
  onAdvancePhase,
  brief,
  twistTriggered,
  onTriggerTwistEarly
}) => {
  const minutes = Math.floor(secondsLeft / 60);
  const seconds = secondsLeft % 60;
  const formattedTime = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
  const percentComplete = ((totalSeconds - secondsLeft) / totalSeconds) * 100;
  const isDangerTime = secondsLeft < 300 && secondsLeft > 0; // under 5 minutes

  return (
    <div className="w-full bg-neutral-900/90 border-b border-neutral-800 px-6 py-2.5 flex flex-wrap items-center justify-between gap-4 backdrop-blur-sm">
      {/* Brand Context Indicator */}
      <div className="flex items-center gap-3">
        <span className="text-xs uppercase tracking-wider text-amber-400 font-bold font-mono">
          CHALLENGE
        </span>
        <span className="text-neutral-500">/</span>
        <span className="font-display font-bold text-white tracking-wide text-base">
          {brief.brandName}
        </span>
        <span className="hidden lg:inline text-xs text-neutral-400 truncate max-w-xs">
          — {brief.tagline}
        </span>
      </div>

      {/* Centerpiece: The Chopped Countdown Timer */}
      <div className="flex items-center gap-4">
        {/* Countdown display */}
        <div className="flex items-center gap-2.5">
          <div
            className={`font-mono tabular-nums text-2xl md:text-3xl font-bold px-3 py-1 rounded-md transition-colors ${
              isDangerTime
                ? 'bg-red-500/20 text-red-400 border border-red-500/40 animate-pulse'
                : 'bg-neutral-950 text-white border border-neutral-800'
            }`}
          >
            {formattedTime}
          </div>

          {/* Time control buttons */}
          <div className="flex items-center gap-1 bg-neutral-950 p-1 rounded-lg border border-neutral-800">
            <button
              onClick={() => {
                sound.pop();
                onTogglePlay();
              }}
              title={isRunning ? 'Pause Clock' : 'Start Clock'}
              className="p-1.5 rounded hover:bg-neutral-800 text-neutral-200 transition-colors"
            >
              {isRunning ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 fill-current text-amber-400" />}
            </button>
            <button
              onClick={() => {
                sound.pop();
                onFastForward(speedMultiplier === 1 ? 10 : speedMultiplier === 10 ? 60 : 1);
              }}
              title="Cycle Speed (1x, 10x Turbo, 60x Blitz)"
              className={`px-2 py-1 text-xs font-mono font-medium rounded transition-colors ${
                speedMultiplier > 1 ? 'bg-amber-400 text-neutral-950 font-bold' : 'text-neutral-400 hover:text-white'
              }`}
            >
              {speedMultiplier}x
            </button>
          </div>
        </div>

        {/* Progress Bar with Twist Marker */}
        <div className="hidden xl:flex flex-col gap-1 w-44">
          <div className="flex justify-between text-[10px] text-neutral-400 font-mono">
            <span>60:00</span>
            <span className="text-amber-400">⚡ 30m Twist</span>
            <span>00:00</span>
          </div>
          <div className="w-full h-1.5 bg-neutral-800 rounded-full relative overflow-hidden">
            <div
              className={`h-full transition-all duration-300 ${
                isDangerTime ? 'bg-red-500' : 'bg-amber-400'
              }`}
              style={{ width: `${percentComplete}%` }}
            />
            {/* Twist point marker at 50% */}
            <div
              className={`absolute top-0 bottom-0 left-1/2 w-0.5 ${
                twistTriggered ? 'bg-emerald-400' : 'bg-amber-400'
              }`}
              title="Surprise Twist Unveiling at 30 Minutes"
            />
          </div>
        </div>
      </div>

      {/* Right Controls: Phase & Actions */}
      <div className="flex items-center gap-2.5">
        {/* Twist indicator button */}
        {twistTriggered ? (
          <div className="flex items-center gap-1.5 text-xs text-amber-300 bg-amber-400/10 px-2.5 py-1.5 rounded-md border border-amber-400/30">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span className="font-semibold">Twist Active</span>
          </div>
        ) : (
          <button
            onClick={() => {
              sound.twistSiren();
              onTriggerTwistEarly();
            }}
            className="flex items-center gap-1 text-xs text-neutral-400 hover:text-amber-300 px-2.5 py-1.5 rounded-md hover:bg-neutral-800 transition-colors"
            title="Deploy the surprise mid-round twist now!"
          >
            <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
            <span>Drop Twist</span>
          </button>
        )}

        {/* Submit / Finish Sprint button */}
        {currentPhase === 'SPRINT_ACTIVE' && (
          <button
            onClick={() => {
              sound.buzzer();
              onAdvancePhase('TIME_UP_PRESENTATION');
            }}
            className="px-3 py-1.5 bg-red-600 hover:bg-red-500 text-white rounded-lg text-xs font-bold transition-colors shadow-sm flex items-center gap-1.5"
          >
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Pencils Down (Submit)</span>
          </button>
        )}

        {currentPhase === 'TIME_UP_PRESENTATION' && (
          <button
            onClick={() => {
              sound.pop();
              onAdvancePhase('AUDIENCE_VOTING');
            }}
            className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-bold transition-colors flex items-center gap-1.5"
          >
            <span>Open Audience Voting</span>
          </button>
        )}

        {currentPhase === 'AUDIENCE_VOTING' && (
          <button
            onClick={() => {
              sound.clocheBell();
              onAdvancePhase('JUDGES_CHOP');
            }}
            className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-neutral-950 rounded-lg text-xs font-bold transition-colors flex items-center gap-1.5"
          >
            <span>Proceed to Chopping Block</span>
          </button>
        )}

        {currentPhase === 'JUDGES_CHOP' && (
          <button
            onClick={() => {
              sound.fanfare();
              onAdvancePhase('FINALE_PODIUM');
            }}
            className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-neutral-950 rounded-lg text-xs font-bold transition-colors flex items-center gap-1.5"
          >
            <span>View Champion Finale</span>
          </button>
        )}
      </div>
    </div>
  );
};
