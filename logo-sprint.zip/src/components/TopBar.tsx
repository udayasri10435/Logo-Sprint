import React from 'react';
import { Volume2, VolumeX, Flame } from 'lucide-react';
import { GamePhase } from '../types';
import { sound } from '../utils/audio';

interface TopBarProps {
  currentPhase: GamePhase;
  onNavigate: (tab: 'arena' | 'rivals' | 'brief' | 'voting' | 'judges' | 'mockups') => void;
  activeTab: string;
  isMuted: boolean;
  onToggleMute: () => void;
  onOpenNewBriefModal: () => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  onNavigate,
  activeTab,
  isMuted,
  onToggleMute,
  onOpenNewBriefModal
}) => {
  return (
    <header className="h-16 px-6 border-b border-neutral-800 bg-neutral-950/90 backdrop-blur-md flex items-center justify-between z-40 select-none">
      {/* Zone 1: Single text element wordmark */}
      <a
        href="#"
        onClick={(e) => {
          e.preventDefault();
          onNavigate('arena');
        }}
        className="font-display text-xl font-bold tracking-tight text-white flex items-center gap-2 hover:text-amber-400 transition-colors"
      >
        <span className="w-2.5 h-2.5 bg-amber-500 rounded-full animate-pulse" />
        Logo Sprint
      </a>

      {/* Zone 2: 4-6 clean text navigation links */}
      <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-neutral-300">
        <button
          onClick={() => onNavigate('arena')}
          className={`transition-colors hover:text-white ${
            activeTab === 'arena' ? 'text-amber-400 font-semibold underline underline-offset-8 decoration-2 decoration-amber-400' : 'text-neutral-400'
          }`}
        >
          Design Arena
        </button>
        <button
          onClick={() => onNavigate('rivals')}
          className={`transition-colors hover:text-white ${
            activeTab === 'rivals' ? 'text-amber-400 font-semibold underline underline-offset-8 decoration-2 decoration-amber-400' : 'text-neutral-400'
          }`}
        >
          Rival Stations
        </button>
        <button
          onClick={() => onNavigate('brief')}
          className={`transition-colors hover:text-white ${
            activeTab === 'brief' ? 'text-amber-400 font-semibold underline underline-offset-8 decoration-2 decoration-amber-400' : 'text-neutral-400'
          }`}
        >
          Mystery Basket
        </button>
        <button
          onClick={() => onNavigate('voting')}
          className={`transition-colors hover:text-white ${
            activeTab === 'voting' ? 'text-amber-400 font-semibold underline underline-offset-8 decoration-2 decoration-amber-400' : 'text-neutral-400'
          }`}
        >
          Audience Voting
        </button>
        <button
          onClick={() => onNavigate('judges')}
          className={`transition-colors hover:text-white ${
            activeTab === 'judges' ? 'text-amber-400 font-semibold underline underline-offset-8 decoration-2 decoration-amber-400' : 'text-neutral-400'
          }`}
        >
          Chopping Block
        </button>
        <button
          onClick={() => onNavigate('mockups')}
          className={`transition-colors hover:text-white ${
            activeTab === 'mockups' ? 'text-amber-400 font-semibold underline underline-offset-8 decoration-2 decoration-amber-400' : 'text-neutral-400'
          }`}
        >
          Brand Mockups
        </button>
      </nav>

      {/* Zone 3: 1-2 primary actions */}
      <div className="flex items-center gap-3">
        <button
          onClick={() => {
            sound.pop();
            onToggleMute();
          }}
          title={isMuted ? 'Unmute Audio' : 'Mute Audio'}
          className="p-2 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
          aria-label="Toggle sound effects"
        >
          {isMuted ? <VolumeX className="w-5 h-5 text-red-400" /> : <Volume2 className="w-5 h-5 text-neutral-300" />}
        </button>

        <button
          onClick={() => {
            sound.pop();
            onOpenNewBriefModal();
          }}
          className="px-3.5 py-2 text-xs font-semibold text-neutral-950 bg-amber-400 rounded-lg hover:bg-amber-300 transition-colors flex items-center gap-1.5 whitespace-nowrap shadow-sm shadow-amber-500/20"
        >
          <Flame className="w-3.5 h-3.5 fill-current" />
          <span>New Mystery Brief</span>
        </button>
      </div>
    </header>
  );
};
