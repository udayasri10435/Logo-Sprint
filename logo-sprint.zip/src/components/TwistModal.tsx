import React from 'react';
import { AlertTriangle, Sparkles, X, ChevronRight } from 'lucide-react';
import { MysteryBrief } from '../types';
import { sound } from '../utils/audio';

interface TwistModalProps {
  brief: MysteryBrief;
  isOpen: boolean;
  onClose: () => void;
}

export const TwistModal: React.FC<TwistModalProps> = ({
  brief,
  isOpen,
  onClose
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-neutral-900 border-2 border-amber-500 rounded-2xl p-6 shadow-2xl shadow-amber-500/20 text-center space-y-4">
        {/* Warning Icon */}
        <div className="w-16 h-16 mx-auto rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 animate-bounce">
          <AlertTriangle className="w-8 h-8" />
        </div>

        <div>
          <div className="text-xs uppercase font-mono tracking-widest text-amber-400 font-bold">
            ⚡ EMERGENCY 30-MINUTE TWIST
          </div>
          <h2 className="font-display text-2xl md:text-3xl font-extrabold text-white mt-1">
            {brief.twist.title}
          </h2>
        </div>

        <p className="text-xs text-neutral-300 leading-relaxed max-w-md mx-auto">
          {brief.twist.description}
        </p>

        <div className="bg-neutral-950 p-4 rounded-xl border border-neutral-800 text-left space-y-1">
          <span className="text-[10px] font-mono uppercase text-amber-400 font-semibold block">
            MANDATORY INGREDIENT ADDITION
          </span>
          <p className="text-xs font-bold text-white">
            {brief.twist.requirement}
          </p>
          <div className="pt-2 text-[11px] text-neutral-400">
            Judges will deduct points from any contestant who submits without this element!
          </div>
        </div>

        <div className="pt-2">
          <button
            onClick={() => {
              sound.pop();
              onClose();
            }}
            className="w-full py-2.5 bg-amber-400 hover:bg-amber-300 text-neutral-950 font-bold text-xs uppercase tracking-wider rounded-xl transition-colors shadow-lg shadow-amber-500/20 flex items-center justify-center gap-1.5"
          >
            <span>Resume Sprint & Adapt</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
