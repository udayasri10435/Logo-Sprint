import { MysteryBrief, Judge } from '../types';

export const JUDGES: Judge[] = [
  {
    id: 'judge-helena',
    name: 'Helena Vance',
    role: 'Global Identity Partner',
    avatarSeed: 'helena',
    quote: 'If your negative space does not resolve into a secondary narrative, you are just drawing shapes.',
    personality: 'Ruthless precision, obsessed with grid balance and optical kerning.'
  },
  {
    id: 'judge-dax',
    name: 'Dax Kurosawa',
    role: 'Avant-Garde Streetwear Director',
    avatarSeed: 'dax',
    quote: 'Safe logos are born to be forgotten. I want danger, tension, and unapologetic attitude.',
    personality: 'Celebrates brutalist quirks, raw typography, and disruptive marks.'
  },
  {
    id: 'judge-marcus',
    name: 'Marcus Sterling',
    role: 'Editorial & Packaging Legend',
    avatarSeed: 'marcus',
    quote: 'Test it at 16 pixels favicon and on a 60-foot airport billboard. Does it hold weight in both?',
    personality: 'Values versatility, timeless craftsmanship, and basket compliance.'
  }
];

export const MYSTERY_BRIEFS: MysteryBrief[] = [
  {
    id: 'velvet-anvil',
    brandName: 'VELVET ANVIL',
    tagline: 'Heavy Metal. Soft Landing.',
    industry: 'Luxury Blacksmith & Speakeasy Bar',
    targetAudience: 'Architects, metal artisans, and craft cocktail purists seeking high drama.',
    story: 'Velvet Anvil combines a high-heat custom forge by day with an ultra-exclusive velvet-curtained absinthe cocktail salon by night. They need a mark that balances extreme industrial brute force with delicate, sensual luxury.',
    basket: {
      symbolMotif: {
        title: 'Anvil & Silk Ribbon',
        detail: 'Must visually marry an anvil (or forged iron tool) with an organic flowing ribbon or feather stroke.',
        icon: 'Hammer'
      },
      colorPalette: [
        { name: 'Molten Ochre', hex: '#F59E0B', role: 'accent' },
        { name: 'Absinthe Emerald', hex: '#10B981', role: 'secondary' },
        { name: 'Raw Cast Iron', hex: '#1E293B', role: 'neutral' },
        { name: 'Champagne Cream', hex: '#FEF3C7', role: 'primary' }
      ],
      paradoxConstraint: {
        title: 'Brutalist Monolith vs Gossamer Flow',
        detail: 'Heavy blocky foundation coupled with at least one whisper-thin geometric stroke.',
        icon: 'Feather'
      },
      wordmarkRule: {
        title: 'Split Personality Type',
        detail: 'VELVET must be elegant or letter-spaced; ANVIL must feel forged and heavy.',
        icon: 'Type'
      }
    },
    twist: {
      triggerMinute: 30,
      title: 'THE SPARK OF MADNESS',
      description: 'The founders just invested in a private aviary! An unexpected canary must be referenced.',
      requirement: 'Incorporate a golden feather arc OR bird silhouette into the mark.',
      bonusIngredient: 'Canary Feather Arc'
    }
  },
  {
    id: 'snailmail-dynamics',
    brandName: 'SNAILMAIL',
    tagline: 'Supersonic Deliveries at Sloth Patience.',
    industry: 'Autonomous Mach-3 Courier Drones',
    targetAudience: 'Venture-backed deep tech founders and impatient luxury collectors.',
    story: 'A hyper-futuristic drone delivery network that prides itself on delivering physical parcels across continents in 40 minutes, yet ironically embraces the slow, patient shell of a snail as its spiritual totem.',
    basket: {
      symbolMotif: {
        title: 'Snail Spiral & Supersonic Wing',
        detail: 'A Fibonacci spiral snail shell engineered with aerodynamic jet-wing propulsion.',
        icon: 'Compass'
      },
      colorPalette: [
        { name: 'Sonic Blue', hex: '#3B82F6', role: 'primary' },
        { name: 'Afterburner Coral', hex: '#F43F5E', role: 'accent' },
        { name: 'Titanium Slate', hex: '#0F172A', role: 'neutral' },
        { name: 'Aero Mint', hex: '#A7F3D0', role: 'secondary' }
      ],
      paradoxConstraint: {
        title: 'Slow Creature / Ludicrous Speed',
        detail: 'Convey intense kinetic forward motion using a creature historically famous for 0.03 mph.',
        icon: 'Zap'
      },
      wordmarkRule: {
        title: 'Aerodynamic Stencil',
        detail: 'Custom tracked wordmark with forward slant or speed slice geometry.',
        icon: 'MoveRight'
      }
    },
    twist: {
      triggerMinute: 30,
      title: 'THE RADAR SIGNATURE',
      description: 'Federal aviation demands a concentric target radar ping in the logo for safety compliance!',
      requirement: 'Include concentric circular rings or radar target coordinates.',
      bonusIngredient: 'Radar Ring Pings'
    }
  },
  {
    id: 'moss-volt',
    brandName: 'MOSS & VOLT',
    tagline: 'Bio-Electric Urban Velocity.',
    industry: 'Bioluminescent Moss Commuter Bikes',
    targetAudience: 'Eco-futurist urbanites who ride glowing botanical bicycles powered by pedal chlorophyll.',
    story: 'Urban bicycles crafted from living Spanish moss fibers that generate bioluminescent green glow from kinetic braking. Nature fused directly into electric mobility.',
    basket: {
      symbolMotif: {
        title: 'Botanical Leaf + High-Voltage Bolt',
        detail: 'Seamless hybrid glyph merging organic venation with a jagged electric spark.',
        icon: 'Zap'
      },
      colorPalette: [
        { name: 'Biolum Lime', hex: '#84CC16', role: 'primary' },
        { name: 'Volt Cyan', hex: '#06B6D4', role: 'accent' },
        { name: 'Deep Forest', hex: '#064E3B', role: 'neutral' },
        { name: 'Solar White', hex: '#F8FAFC', role: 'secondary' }
      ],
      paradoxConstraint: {
        title: 'Living Cellular Organism + High Voltage Hardware',
        detail: 'Must look like it grew in a wet mossy forest and was assembled by Tesla engineers.',
        icon: 'Leaf'
      },
      wordmarkRule: {
        title: 'Ampersand Integration',
        detail: 'The "&" sign must bridge the two words like a physical power cable or vine.',
        icon: 'GitFork'
      }
    },
    twist: {
      triggerMinute: 30,
      title: 'CROSS-POLLINATION SPIKE',
      description: 'The laboratory accidentally cultivated honeybee pheromones into the frame paint!',
      requirement: 'Add a hexagonal honeycomb cell or honey drop emblem to the lockup.',
      bonusIngredient: 'Hexagonal Honeycomb Geometry'
    }
  },
  {
    id: 'cosmic-crumb',
    brandName: 'COSMIC CRUMB',
    tagline: 'Fresh Sourdough for the Outer Orbit.',
    industry: 'Zero-Gravity Interstellar Bakery',
    targetAudience: 'Commercial space tourists craving warm crusty artisanal bread in zero-G.',
    story: 'Baking bread in zero gravity without loose crumbs clogging the air filters was considered impossible until Cosmic Crumb patented magnetic yeast. Now servicing Lunar and Martian orbital flights.',
    basket: {
      symbolMotif: {
        title: 'Saturn Ring + Sourdough Boule',
        detail: 'Planetary orbit trajectory encircling a scored crusty loaf of bread.',
        icon: 'Sparkles'
      },
      colorPalette: [
        { name: 'Deep Orbit', hex: '#18181B', role: 'neutral' },
        { name: 'Golden Crust', hex: '#D97706', role: 'accent' },
        { name: 'Nebula Purple', hex: '#8B5CF6', role: 'primary' },
        { name: 'Stardust Cream', hex: '#FFFBEB', role: 'secondary' }
      ],
      paradoxConstraint: {
        title: 'Rustic Medieval Hearth vs Astrophysics',
        detail: 'Scorched artisan flour texture translated into sleek NASA vector precision.',
        icon: 'Orbit'
      },
      wordmarkRule: {
        title: 'Zero-G Floating Letters',
        detail: 'Wordmark must feature staggered or buoyant letter elevation.',
        icon: 'Sliders'
      }
    },
    twist: {
      triggerMinute: 30,
      title: 'MICROMETEORITE IMPACT',
      description: 'The space station galley just survived a micro-meteoroid! They want battle scars!',
      requirement: 'Add a geometric starburst or comet tail flare intersecting the design.',
      bonusIngredient: 'Stellar Impact Starburst'
    }
  },
  {
    id: 'puffer-peak',
    brandName: 'PUFFER & PEAK',
    tagline: 'Summit-Grade Down for Pocket Predators.',
    industry: 'High-Altitude Mountaineering Apparel for Chihuahuas',
    targetAudience: 'Extreme expedition climbers who refuse to summit K2 without their miniature dogs.',
    story: 'Ultra-lightweight 900-fill down alpine parkas, crampon booties, and ice axes engineered specifically for 4-pound toy dogs braving blizzard conditions in the Himalayas.',
    basket: {
      symbolMotif: {
        title: 'Jagged Alpine Peak + Miniature Dog Silhouette',
        detail: 'Twin mountain ridges forming or sheltering a tiny perked-ear canine silhouette.',
        icon: 'Mountain'
      },
      colorPalette: [
        { name: 'Emergency Orange', hex: '#EA580C', role: 'accent' },
        { name: 'Glacial Ice', hex: '#38BDF8', role: 'secondary' },
        { name: 'Alpine Granite', hex: '#334155', role: 'neutral' },
        { name: 'Snowblind White', hex: '#FFFFFF', role: 'primary' }
      ],
      paradoxConstraint: {
        title: 'Survivalist Hardcore vs Adorable Cuteness',
        detail: 'Deadly serious mountaineering technical gear aesthetic with miniature canine proportions.',
        icon: 'Shield'
      },
      wordmarkRule: {
        title: 'Staggered Elevation Scale',
        detail: 'PUFFER must be thick and rounded; PEAK must be sharp and angular.',
        icon: 'Type'
      }
    },
    twist: {
      triggerMinute: 30,
      title: 'AVALANCHE RESCUE BEACON',
      description: 'Swiss search-and-rescue certified the brand! An emergency cross is now mandatory.',
      requirement: 'Include a rescue medical cross (+) or beacon broadcast wave.',
      bonusIngredient: 'Rescue Cross Glyph'
    }
  }
];

export const INITIAL_AUDIENCE_CHAT: Array<{ username: string; text: string; color: string; badge?: string }> = [
  { username: 'TypeNerd_99', text: 'LETS GOOOOO! Chopped for designers is finally live! 🎨🔥', color: '#3B82F6', badge: 'VIP' },
  { username: 'SwissGridLover', text: 'That basket palette is diabolical... how do you make those work?!', color: '#10B981' },
  { username: 'KerningPolice', text: 'If station 2 messes up the tracking I am calling the authorities', color: '#EC4899', badge: 'MOD' },
  { username: 'VectorQueen', text: 'Watch out for the 30-minute twist, last week it was brutal lol', color: '#8B5CF6' },
  { username: 'HelenaFanClub', text: 'Helena Vance looks ready to obliterate someone’s bezier curves', color: '#F59E0B' },
  { username: 'MinimalistMax', text: 'Station 1 (Player) already has an ambitious layout, Rooting for you!', color: '#06B6D4' }
];
