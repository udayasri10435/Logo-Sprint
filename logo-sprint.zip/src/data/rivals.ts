import { CanvasElement, Designer, MysteryBrief } from '../types';

export function getRivalDesigners(brief: MysteryBrief): Designer[] {
  const p = brief.basket.colorPalette;
  const col0 = p[0].hex;
  const col1 = p[1].hex;
  const col2 = p[2].hex;
  const col3 = p[3].hex;

  // Station 2: Anya Chen - Swiss Modernist
  const anyaElements: CanvasElement[] = [
    {
      id: 'anya-1',
      type: 'shape',
      x: 140,
      y: 110,
      width: 140,
      height: 140,
      rotation: 0,
      opacity: 1,
      fill: col0,
      stroke: 'transparent',
      strokeWidth: 0,
      shapeType: 'circle',
      zIndex: 1
    },
    {
      id: 'anya-2',
      type: 'shape',
      x: 180,
      y: 90,
      width: 120,
      height: 120,
      rotation: 45,
      opacity: 0.9,
      fill: col1,
      stroke: col2,
      strokeWidth: 4,
      shapeType: 'diamond',
      zIndex: 2
    },
    {
      id: 'anya-3',
      type: 'shape',
      x: 210,
      y: 150,
      width: 60,
      height: 60,
      rotation: 0,
      opacity: 1,
      fill: col3,
      stroke: 'transparent',
      strokeWidth: 0,
      shapeType: 'star',
      zIndex: 3
    },
    {
      id: 'anya-4',
      type: 'text',
      x: 80,
      y: 290,
      width: 260,
      height: 40,
      rotation: 0,
      opacity: 1,
      fill: col3,
      stroke: 'transparent',
      strokeWidth: 0,
      text: brief.brandName,
      fontFamily: 'Syne',
      fontSize: 22,
      fontWeight: 800,
      letterSpacing: 4,
      textTransform: 'uppercase',
      zIndex: 4
    },
    {
      id: 'anya-5',
      type: 'text',
      x: 100,
      y: 330,
      width: 220,
      height: 25,
      rotation: 0,
      opacity: 0.7,
      fill: col0,
      stroke: 'transparent',
      strokeWidth: 0,
      text: brief.tagline,
      fontFamily: 'Plus Jakarta Sans',
      fontSize: 10,
      fontWeight: 600,
      letterSpacing: 2,
      textTransform: 'uppercase',
      zIndex: 5
    }
  ];

  // Station 3: Milo Vance - Neo-Brutalist Typographer
  const miloElements: CanvasElement[] = [
    {
      id: 'milo-1',
      type: 'shape',
      x: 110,
      y: 90,
      width: 200,
      height: 180,
      rotation: 0,
      opacity: 1,
      fill: col2,
      stroke: col0,
      strokeWidth: 6,
      shapeType: 'shield',
      zIndex: 1
    },
    {
      id: 'milo-2',
      type: 'shape',
      x: 160,
      y: 130,
      width: 100,
      height: 80,
      rotation: 0,
      opacity: 1,
      fill: col1,
      stroke: 'transparent',
      strokeWidth: 0,
      shapeType: 'hexagon',
      zIndex: 2
    },
    {
      id: 'milo-3',
      type: 'shape',
      x: 190,
      y: 155,
      width: 40,
      height: 40,
      rotation: 0,
      opacity: 1,
      fill: col3,
      stroke: 'transparent',
      strokeWidth: 0,
      shapeType: 'pill',
      zIndex: 3
    },
    {
      id: 'milo-4',
      type: 'text',
      x: 70,
      y: 300,
      width: 280,
      height: 45,
      rotation: 0,
      opacity: 1,
      fill: col0,
      stroke: 'transparent',
      strokeWidth: 0,
      text: brief.brandName,
      fontFamily: 'JetBrains Mono',
      fontSize: 24,
      fontWeight: 800,
      letterSpacing: 1,
      textTransform: 'uppercase',
      zIndex: 4
    }
  ];

  // Station 4: Jax Sterling - Playful Mascot & Emblem Designer
  const jaxElements: CanvasElement[] = [
    {
      id: 'jax-1',
      type: 'shape',
      x: 120,
      y: 80,
      width: 180,
      height: 180,
      rotation: 12,
      opacity: 1,
      fill: col3,
      stroke: col1,
      strokeWidth: 4,
      shapeType: 'blob',
      zIndex: 1
    },
    {
      id: 'jax-2',
      type: 'shape',
      x: 150,
      y: 110,
      width: 120,
      height: 120,
      rotation: -6,
      opacity: 1,
      fill: col0,
      stroke: col2,
      strokeWidth: 3,
      shapeType: 'ring',
      zIndex: 2
    },
    {
      id: 'jax-3',
      type: 'shape',
      x: 175,
      y: 140,
      width: 70,
      height: 60,
      rotation: 0,
      opacity: 1,
      fill: col1,
      stroke: 'transparent',
      strokeWidth: 0,
      shapeType: 'wave',
      zIndex: 3
    },
    {
      id: 'jax-4',
      type: 'text',
      x: 80,
      y: 295,
      width: 260,
      height: 40,
      rotation: -2,
      opacity: 1,
      fill: col2,
      stroke: 'transparent',
      strokeWidth: 0,
      text: brief.brandName,
      fontFamily: 'Syne',
      fontSize: 23,
      fontWeight: 700,
      letterSpacing: 3,
      textTransform: 'uppercase',
      zIndex: 4
    },
    {
      id: 'jax-5',
      type: 'shape',
      x: 100,
      y: 335,
      width: 220,
      height: 8,
      rotation: 0,
      opacity: 0.9,
      fill: col0,
      stroke: 'transparent',
      strokeWidth: 0,
      shapeType: 'pill',
      zIndex: 5
    }
  ];

  return [
    {
      id: 'station-2',
      stationNumber: 2,
      name: 'Anya Chen',
      title: 'Art Director · Basel & Taipei',
      isUser: false,
      avatarSeed: 'anya',
      styleSchool: 'Swiss Mathematical Grid',
      bio: 'Known for razor-sharp geometric harmony and zero tolerance for superfluous ornament.',
      currentThought: 'Calibrating golden-ratio radii against the basket palette...',
      elements: anyaElements,
      rationale: `Constructed an asymmetric geometric lockup marrying the ${brief.basket.symbolMotif.title} into a unified circular mark.`,
      audienceVotes: 24,
      twistIntegrated: true,
      isChopped: false,
      critique: {
        judgeScores: {
          creativity: 88,
          compliance: 92,
          craft: 94,
          presentation: 90
        },
        verdict: 'Impeccable structural discipline. The typography sits with absolute architectural authority.',
        highlights: ['Pristine mathematical balance', 'Flawless execution of primary basket palette'],
        weakness: 'Slightly cold; could breathe with more visceral soul.'
      }
    },
    {
      id: 'station-3',
      stationNumber: 3,
      name: 'Milo Vance',
      title: 'Type Designer · Berlin',
      isUser: false,
      avatarSeed: 'milo',
      styleSchool: 'Neo-Brutalist Monolith',
      bio: 'Former graffiti rebel turned award-winning foundry master. Loves heavy strokes and stark raw contrast.',
      currentThought: 'Thickening the outer shield contour to emphasize industrial presence...',
      elements: miloElements,
      rationale: `Subverted the brief by encasing the core metaphor in an unapologetic heavy armor shield with forged mono letterforms.`,
      audienceVotes: 18,
      twistIntegrated: false,
      isChopped: false,
      critique: {
        judgeScores: {
          creativity: 82,
          compliance: 71,
          craft: 85,
          presentation: 78
        },
        verdict: 'Heavy and potent, but dangerously close to ignoring the softer basket paradox requirement.',
        highlights: ['Uncompromising punchy contrast', 'Distinctive industrial weight'],
        weakness: 'Neglected the surprise twist requirement; clunky at small scale.'
      }
    },
    {
      id: 'station-4',
      stationNumber: 4,
      name: 'Jax Sterling',
      title: 'Brand Illustrator · Brooklyn',
      isUser: false,
      avatarSeed: 'jax',
      styleSchool: 'Expressive Emblem & Mascot',
      bio: 'Specializes in high-energy streetwear badges, kinetic lines, and organic character silhouettes.',
      currentThought: 'Injecting kinetic fluid arcs to make the lockup feel alive...',
      elements: jaxElements,
      rationale: `Created a fluid badge mark combining organic blob contouring with dynamic wave vectors to bring joy to the category.`,
      audienceVotes: 29,
      twistIntegrated: true,
      isChopped: false,
      critique: {
        judgeScores: {
          creativity: 91,
          compliance: 86,
          craft: 89,
          presentation: 88
        },
        verdict: 'Electric visual magnetism that immediately captured the live audience stream.',
        highlights: ['Effortless visual flow', 'Clever integration of the surprise ingredient'],
        weakness: 'Slightly crowded interior negative space.'
      }
    }
  ];
}
