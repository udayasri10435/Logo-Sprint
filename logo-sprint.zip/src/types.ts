export type ShapeType =
  | 'rect'
  | 'circle'
  | 'triangle'
  | 'star'
  | 'shield'
  | 'hexagon'
  | 'diamond'
  | 'ring'
  | 'pill'
  | 'cross'
  | 'arc'
  | 'wave'
  | 'ribbon'
  | 'blob';

export interface CanvasElement {
  id: string;
  type: 'shape' | 'text' | 'icon' | 'path';
  x: number;
  y: number;
  width: number;
  height: number;
  rotation: number;
  opacity: number;
  fill: string;
  stroke: string;
  strokeWidth: number;
  shapeType?: ShapeType;
  text?: string;
  fontFamily?: string;
  fontSize?: number;
  fontWeight?: string | number;
  letterSpacing?: number;
  textTransform?: 'uppercase' | 'lowercase' | 'none';
  iconName?: string;
  pathData?: string;
  zIndex: number;
}

export interface BasketIngredient {
  title: string;
  detail: string;
  icon: string;
}

export interface BrandColor {
  name: string;
  hex: string;
  role: 'primary' | 'secondary' | 'accent' | 'neutral';
}

export interface MysteryBrief {
  id: string;
  brandName: string;
  tagline: string;
  industry: string;
  targetAudience: string;
  story: string;
  basket: {
    symbolMotif: BasketIngredient;
    colorPalette: BrandColor[];
    paradoxConstraint: BasketIngredient;
    wordmarkRule: BasketIngredient;
  };
  twist: {
    triggerMinute: number; // e.g. at 30 minutes remaining
    title: string;
    description: string;
    requirement: string;
    bonusIngredient: string;
  };
}

export interface Judge {
  id: string;
  name: string;
  role: string;
  avatarSeed: string;
  quote: string;
  personality: string;
}

export interface Designer {
  id: string;
  stationNumber: number;
  name: string;
  title: string;
  isUser: boolean;
  avatarSeed: string;
  styleSchool: string;
  bio: string;
  currentThought: string;
  elements: CanvasElement[];
  rationale: string;
  audienceVotes: number;
  twistIntegrated: boolean;
  isChopped: boolean;
  critique?: {
    judgeScores: {
      creativity: number;
      compliance: number;
      craft: number;
      presentation: number;
    };
    verdict: string;
    highlights: string[];
    weakness: string;
  };
}

export interface AudienceComment {
  id: string;
  username: string;
  avatarColor: string;
  text: string;
  timestamp: string;
  badge?: string;
}

export type GamePhase =
  | 'BRIEF_UNVEILING'     // Inspect the mystery basket & rules
  | 'SPRINT_ACTIVE'        // 60-minute countdown, live canvas editing
  | 'TIME_UP_PRESENTATION' // Pencils down! Contestants show their marks
  | 'AUDIENCE_VOTING'      // Live stream votes cast
  | 'JUDGES_CHOP'          // Judges deliberate & eliminate someone
  | 'FINALE_PODIUM';       // Champion announced, trophy awarded, mockup gallery
