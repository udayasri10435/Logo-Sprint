import React from 'react';

// Vector Paths & SVG Helper for Logo Sprint Canvas

export interface MotifDefinition {
  id: string;
  name: string;
  category: 'basket' | 'geometric' | 'nature' | 'industrial' | 'celestial';
  viewBox: string;
  path: string;
}

export const MOTIF_LIBRARY: MotifDefinition[] = [
  // Basket & Challenge Motifs
  {
    id: 'anvil',
    name: 'Heavy Anvil',
    category: 'basket',
    viewBox: '0 0 100 100',
    path: 'M15,40 L35,40 L38,28 L85,28 C80,38 72,42 62,44 L62,55 C68,58 74,66 82,72 L18,72 C26,66 32,58 38,55 L38,44 L15,44 Z'
  },
  {
    id: 'silk-ribbon',
    name: 'Flowing Ribbon',
    category: 'basket',
    viewBox: '0 0 100 100',
    path: 'M10,65 C30,30 45,75 70,40 C85,20 95,35 90,50 C80,75 55,25 35,60 C25,75 15,75 10,65 Z'
  },
  {
    id: 'snail-spiral',
    name: 'Fibonacci Snail',
    category: 'basket',
    viewBox: '0 0 100 100',
    path: 'M85,55 C85,75 68,85 50,85 C28,85 15,70 15,50 C15,28 32,15 52,15 C70,15 80,28 80,44 C80,58 70,68 56,68 C44,68 36,60 36,48 C36,38 42,32 50,32 C56,32 60,36 60,42'
  },
  {
    id: 'supersonic-wing',
    name: 'Aero Wing',
    category: 'basket',
    viewBox: '0 0 100 100',
    path: 'M10,75 L85,20 L95,25 L65,80 L35,80 Z'
  },
  {
    id: 'leaf-node',
    name: 'Botanical Leaf',
    category: 'nature',
    viewBox: '0 0 100 100',
    path: 'M50,10 C20,30 15,65 50,90 C85,65 80,30 50,10 Z M50,20 L50,80'
  },
  {
    id: 'electric-bolt',
    name: 'Voltage Spark',
    category: 'industrial',
    viewBox: '0 0 100 100',
    path: 'M55,10 L25,52 L48,52 L38,90 L75,44 L50,44 Z'
  },
  {
    id: 'honeycomb-cell',
    name: 'Hex Honeycomb',
    category: 'nature',
    viewBox: '0 0 100 100',
    path: 'M50,15 L85,35 L85,75 L50,95 L15,75 L15,35 Z'
  },
  {
    id: 'saturn-ring',
    name: 'Orbiting Planet',
    category: 'celestial',
    viewBox: '0 0 100 100',
    path: 'M50,30 A20,20 0 1 0 50,70 A20,20 0 1 0 50,30 M15,55 C20,40 70,30 88,48 C95,55 85,62 70,65 C40,72 18,65 15,55'
  },
  {
    id: 'bread-boule',
    name: 'Artisan Boule',
    category: 'basket',
    viewBox: '0 0 100 100',
    path: 'M15,65 C15,35 32,20 50,20 C68,20 85,35 85,65 C85,78 70,82 50,82 C30,82 15,78 15,65 Z M35,32 Q50,45 65,32 M30,48 Q50,60 70,48'
  },
  {
    id: 'alpine-peak',
    name: 'Twin Peaks',
    category: 'nature',
    viewBox: '0 0 100 100',
    path: 'M10,80 L45,20 L65,55 L75,40 L95,80 Z M38,32 L45,45 L52,38 M70,48 L75,55 L82,50'
  },
  {
    id: 'dog-canine',
    name: 'Pocket Canine',
    category: 'nature',
    viewBox: '0 0 100 100',
    path: 'M30,75 L30,45 L20,25 L40,35 L60,35 L80,25 L70,45 L70,75 Z M42,50 A4,4 0 1 1 38,50 M62,50 A4,4 0 1 1 58,50 M50,62 L46,56 L54,56 Z'
  },
  {
    id: 'rescue-cross',
    name: 'Rescue Cross',
    category: 'basket',
    viewBox: '0 0 100 100',
    path: 'M40,15 L60,15 L60,40 L85,40 L85,60 L60,60 L60,85 L40,85 L40,60 L15,60 L15,40 L40,40 Z'
  },
  // Geometric & Heraldic Classics
  {
    id: 'crown',
    name: 'Imperial Crown',
    category: 'geometric',
    viewBox: '0 0 100 100',
    path: 'M15,75 L20,35 L40,55 L50,25 L60,55 L80,35 L85,75 Z'
  },
  {
    id: 'shield-crest',
    name: 'Heraldic Shield',
    category: 'geometric',
    viewBox: '0 0 100 100',
    path: 'M20,20 L80,20 L80,50 C80,75 50,88 50,88 C50,88 20,75 20,50 Z'
  },
  {
    id: 'diamond-gem',
    name: 'Brilliant Diamond',
    category: 'geometric',
    viewBox: '0 0 100 100',
    path: 'M30,20 L70,20 L90,45 L50,85 L10,45 Z M10,45 L90,45 M30,20 L50,85 L70,20 M30,20 L40,45 L50,20 L60,45 L70,20'
  },
  {
    id: 'all-seeing-eye',
    name: 'Geometric Eye',
    category: 'celestial',
    viewBox: '0 0 100 100',
    path: 'M10,50 C25,25 75,25 90,50 C75,75 25,75 10,50 Z M50,35 A15,15 0 1 0 50,65 A15,15 0 1 0 50,35 M50,44 A6,6 0 1 0 50,56 A6,6 0 1 0 50,44'
  },
  {
    id: 'feather-quill',
    name: 'Feather Stroke',
    category: 'nature',
    viewBox: '0 0 100 100',
    path: 'M80,15 C45,30 20,60 15,85 C35,75 65,50 80,15 Z M25,75 L70,25'
  },
  {
    id: 'starburst-spark',
    name: '8-Point Starburst',
    category: 'celestial',
    viewBox: '0 0 100 100',
    path: 'M50,10 L58,38 L88,38 L64,54 L73,82 L50,66 L27,82 L36,54 L12,38 L42,38 Z'
  },
  {
    id: 'compass-rose',
    name: 'Drafting Compass',
    category: 'industrial',
    viewBox: '0 0 100 100',
    path: 'M50,15 L58,42 L85,50 L58,58 L50,85 L42,58 L15,50 L42,42 Z'
  },
  {
    id: 'gear-sprocket',
    name: 'Precision Gear',
    category: 'industrial',
    viewBox: '0 0 100 100',
    path: 'M45,15 L55,15 L57,25 L65,28 L73,22 L80,29 L74,37 L77,45 L87,47 L87,57 L77,59 L74,67 L80,75 L73,82 L65,76 L57,79 L55,89 L45,89 L43,79 L35,76 L27,82 L20,75 L26,67 L23,59 L13,57 L13,47 L23,45 L26,37 L20,29 L27,22 L35,28 L43,25 Z M50,38 A12,12 0 1 0 50,62 A12,12 0 1 0 50,38'
  },
  {
    id: 'flame-ember',
    name: 'Forge Flame',
    category: 'industrial',
    viewBox: '0 0 100 100',
    path: 'M50,15 C65,35 80,50 80,68 C80,82 68,90 50,90 C32,90 20,82 20,68 C20,52 35,42 42,28 C45,38 52,42 50,52 C54,48 56,40 50,15 Z'
  }
];

export function renderShapeSvg(
  shapeType: string,
  width: number,
  height: number,
  fill: string,
  stroke: string,
  strokeWidth: number
): React.ReactElement {
  const w = width;
  const h = height;

  switch (shapeType) {
    case 'circle':
      return <circle cx={w / 2} cy={h / 2} r={Math.min(w, h) / 2 - strokeWidth} fill={fill} stroke={stroke} strokeWidth={strokeWidth} />;
    case 'rect':
      return <rect x={strokeWidth / 2} y={strokeWidth / 2} width={w - strokeWidth} height={h - strokeWidth} rx={4} fill={fill} stroke={stroke} strokeWidth={strokeWidth} />;
    case 'pill':
      return <rect x={strokeWidth / 2} y={strokeWidth / 2} width={w - strokeWidth} height={h - strokeWidth} rx={Math.min(w, h) / 2} fill={fill} stroke={stroke} strokeWidth={strokeWidth} />;
    case 'triangle':
      return <polygon points={`${w / 2},${strokeWidth} ${w - strokeWidth},${h - strokeWidth} ${strokeWidth},${h - strokeWidth}`} fill={fill} stroke={stroke} strokeWidth={strokeWidth} strokeLinejoin="round" />;
    case 'diamond':
      return <polygon points={`${w / 2},${strokeWidth} ${w - strokeWidth},${h / 2} ${w / 2},${h - strokeWidth} ${strokeWidth},${h / 2}`} fill={fill} stroke={stroke} strokeWidth={strokeWidth} strokeLinejoin="round" />;
    case 'hexagon': {
      const p1 = `${w * 0.25},${strokeWidth}`;
      const p2 = `${w * 0.75},${strokeWidth}`;
      const p3 = `${w - strokeWidth},${h / 2}`;
      const p4 = `${w * 0.75},${h - strokeWidth}`;
      const p5 = `${w * 0.25},${h - strokeWidth}`;
      const p6 = `${strokeWidth},${h / 2}`;
      return <polygon points={`${p1} ${p2} ${p3} ${p4} ${p5} ${p6}`} fill={fill} stroke={stroke} strokeWidth={strokeWidth} strokeLinejoin="round" />;
    }
    case 'star': {
      const cx = w / 2;
      const cy = h / 2;
      const spikes = 5;
      const outerR = Math.min(w, h) / 2 - strokeWidth;
      const innerR = outerR * 0.45;
      let points = '';
      for (let i = 0; i < spikes * 2; i++) {
        const r = i % 2 === 0 ? outerR : innerR;
        const angle = (i * Math.PI) / spikes - Math.PI / 2;
        const x = cx + Math.cos(angle) * r;
        const y = cy + Math.sin(angle) * r;
        points += `${x},${y} `;
      }
      return <polygon points={points.trim()} fill={fill} stroke={stroke} strokeWidth={strokeWidth} strokeLinejoin="round" />;
    }
    case 'shield': {
      const d = `M${strokeWidth},${strokeWidth} L${w - strokeWidth},${strokeWidth} L${w - strokeWidth},${h * 0.55} C${w - strokeWidth},${h * 0.85} ${w / 2},${h - strokeWidth} ${w / 2},${h - strokeWidth} C${w / 2},${h - strokeWidth} ${strokeWidth},${h * 0.85} ${strokeWidth},${h * 0.55} Z`;
      return <path d={d} fill={fill} stroke={stroke} strokeWidth={strokeWidth} strokeLinejoin="round" />;
    }
    case 'ring': {
      const rOuter = Math.min(w, h) / 2 - strokeWidth;
      const rInner = rOuter * 0.65;
      return (
        <path
          d={`M${w / 2},${h / 2 - rOuter} A${rOuter},${rOuter} 0 1,0 ${w / 2},${h / 2 + rOuter} A${rOuter},${rOuter} 0 1,0 ${w / 2},${h / 2 - rOuter} M${w / 2},${h / 2 - rInner} A${rInner},${rInner} 0 1,1 ${w / 2},${h / 2 + rInner} A${rInner},${rInner} 0 1,1 ${w / 2},${h / 2 - rInner}`}
          fill={fill}
          stroke={stroke}
          strokeWidth={strokeWidth}
          fillRule="evenodd"
        />
      );
    }
    case 'cross': {
      const thick = Math.min(w, h) * 0.3;
      const x1 = (w - thick) / 2;
      const x2 = (w + thick) / 2;
      const y1 = (h - thick) / 2;
      const y2 = (h + thick) / 2;
      const d = `M${x1},${strokeWidth} L${x2},${strokeWidth} L${x2},${y1} L${w - strokeWidth},${y1} L${w - strokeWidth},${y2} L${x2},${y2} L${x2},${h - strokeWidth} L${x1},${h - strokeWidth} L${x1},${y2} L${strokeWidth},${y2} L${strokeWidth},${y1} L${x1},${y1} Z`;
      return <path d={d} fill={fill} stroke={stroke} strokeWidth={strokeWidth} strokeLinejoin="round" />;
    }
    case 'blob': {
      const d = `M${w * 0.5},${h * 0.08} C${w * 0.85},${h * 0.05} ${w * 0.98},${h * 0.4} ${w * 0.88},${h * 0.75} C${w * 0.78},${h * 0.98} ${w * 0.35},${h * 0.96} ${w * 0.15},${h * 0.8} C${w * -0.02},${h * 0.6} ${w * 0.08},${h * 0.25} ${w * 0.5},${h * 0.08} Z`;
      return <path d={d} fill={fill} stroke={stroke} strokeWidth={strokeWidth} />;
    }
    case 'wave': {
      const d = `M${strokeWidth},${h * 0.6} Q${w * 0.25},${h * 0.15} ${w * 0.5},${h * 0.6} T${w - strokeWidth},${h * 0.6} L${w - strokeWidth},${h - strokeWidth} L${strokeWidth},${h - strokeWidth} Z`;
      return <path d={d} fill={fill} stroke={stroke} strokeWidth={strokeWidth} />;
    }
    default:
      return <rect x={strokeWidth / 2} y={strokeWidth / 2} width={w - strokeWidth} height={h - strokeWidth} rx={4} fill={fill} stroke={stroke} strokeWidth={strokeWidth} />;
  }
}
